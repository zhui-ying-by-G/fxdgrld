# 暮秋物语 · 第二辑《共生》—— 六张壁纸出图套件

> 第一辑是"她在秋天里看见东西"；第二辑只做一件事：**把"只有他们看得见的伴生灵"拍成一天里的三个时刻**。
> 女生三张：阁楼 → 柿巷 → 河堤；男生三张：废站 → 银杏参道 → 夜车。
> 晨 / 暮 / 夜 各一对，可做双屏壁纸，也可单张成组。

---

## 0. 怎么用（三步）

1. 打开 `暮秋物语-第二辑-prompts.json`，`full` 字段就是可直接粘贴的英文提示词（`zh` 字段是给即梦/可灵用的中文版）。
2. 把 `01晚秋.png`、`02穆余.png` 当角色参考图喂给模型（方法见 §4），参考强度 60–80%。
3. 每张先出 4 张，按 §5 的清单挑一张，再放大到 2560×1440 交付。

---

## 1. 锁定卡（LOCK）

提示词里用 `{A}{B}{C}{D}{S}` 占位，替换成下面原文。**这四段一个字都不要改**——它们是人物的锚。

| 代号 | 内容 |
|---|---|
| **{A} 晚秋** | `slim 17-year-old girl with long warm chestnut-brown hair in a low side ponytail tied with a thin dark-brown ribbon, soft rounded face, large amber-brown eyes, a small beige bandage on her left cheek, quiet gentle expression` |
| **{B} 穆余** | `tall lean 19-year-old young man with short messy black hair, a long fringe falling over his eyebrows, a few strands sticking up at the crown, narrow dark-grey eyes, calm sleepy gaze, a black vintage 35mm film camera on a brown leather strap across his body` |
| **{C} 浩禾** | `palm-sized golden-orange squirrel with a huge fluffy cream-tipped tail and cream belly, dog-like body language, sitting up on its hind legs with its tail wagging in a wide arc` |
| **{D} 小耶** | `small white fox kit with cream-white fur and a faint apricot tail tip, big pointed ears, narrow amber eyes, cat-like body language, sitting with its tail wrapped around its paws, aloof` |
| **{S} 画风** | `Japanese anime illustration, delicate fine ink linework, transparent watercolor and gouache washes, visible cold-press paper grain, soft colour bleed, muted filmic grade, cinematic environmental composition with generous negative space, 4k detail` |

**负向（所有图共用）：**

```
text, watermark, signature, logo, extra fingers, deformed hands, bad anatomy, extra limbs, cloned face, twin characters, two squirrels, two foxes, photorealistic, 3d render, plastic skin, oversaturated colours, heavy vignette, cluttered composition, chibi, nsfw
```

**绝对不能变的三处细节**（模型最容易丢）：
- 晚秋左脸颊那块**米色小创可贴**——这是她的识别符，丢了就不是同一个人。
- 晚秋的**低侧马尾 + 深棕细丝带**（不是高马尾、不是双马尾）。
- 穆余脖子上**棕色皮背带的黑相机**——就算他不拍，相机也得在身上。

---

## 2. 六张总表

| 编号 | 文件名 | 人物 | 场景 | 时刻 | 主色 | 配对 |
|---|---|---|---|---|---|---|
| ① | `wanqiu-17-bookshop-attic` | 晚秋 | 旧书店阁楼 | 雨后清晨 | 芥末黄 / 灰白 | ④ 晨 |
| ② | `wanqiu-18-persimmon-alley` | 晚秋 | 老城柿巷 | 黄昏最后一刻 | 墨绿 / 柿橙 | ⑤ 暮 |
| ③ | `wanqiu-19-frost-embankment` | 晚秋 | 河堤石阶 | 蓝调时刻·初霜 | 燕麦 / 钠灯橙 | ⑥ 夜 |
| ④ | `muyu-13-empty-platform` | 穆余 | 废弃乡间站台 | 拂晓浓雾 | 炭灰 / 冷蓝 | ① 晨 |
| ⑤ | `muyu-14-ginkgo-shrine` | 穆余 | 神社银杏参道 | 黄昏逆光 | 锈橙 / 金黄 | ② 暮 |
| ⑥ | `muyu-15-night-train` | 穆余 | 夜行列车窗边 | 深夜 | 黑 / 冷蓝 + 橙 | ③ 夜 |

---

## 3. 逐张

### ① 阁楼晨读 · `wanqiu-17-bookshop-attic`

- **一句话**：她借着窗光读一页旧书，浩禾在包袋里睡着，尾巴垂到她手腕上。
- **服装（本辑独有）**：芥末黄针织背心 + 白衬衫（领口松开）+ 炭灰羊毛 A 字中长裙 + 棕色系带皮靴 + 玳瑁发夹（马尾改成半扎）。
- **伴生灵**：浩禾睡在帆布托特包口袋里，只露出头和奶油色尾尖，尾巴搭在她手腕上——**全辑唯一一张它在睡觉**，做节奏留白。
- **构图**：35mm，视平线，人物站右三分线；左侧一整面灰白灰泥墙留空（放桌面图标）。窗在人物右后方，形成半逆光。
- **光**：阴天冷光从右后来，地板反一点暖；灰尘在光柱里悬浮。
- **易错点**：模型会把她画成"站在书架前正面看书"，要强调 `half-turned in profile` 和 `window behind her to the right`。

**提示词**
```
a {A} standing half-turned in profile in a dusty second-hand bookshop attic on a wet late-autumn
morning, holding an open book up toward the pale grey daylight of a tall window behind her to the
right, dust motes drifting in the beam; she wears a mustard-yellow knit vest over a white collared
shirt, a long charcoal wool A-line skirt, brown lace-up leather boots and a tortoiseshell hair clip;
a {C} asleep curled inside the pocket of her canvas tote bag, only its head and cream-tipped tail
spilling out, the tail resting across her wrist; leaning towers of worn books, dark wooden shelves,
a rolling ladder; cold overcast light from the right with a faint warm bounce off the floorboards;
35mm lens, eye level, subject on the right third, a large empty pale plaster wall on the left,
faint film grain; {S}
```

---

### ② 风起的柿巷 · `wanqiu-18-persimmon-alley`

- **一句话**：她拎着一袋柿子回头，风把围巾和落叶一起掀起来；浩禾从帽兜里探出头。
- **服装**：墨绿牛角扣大衣（扣子扣一半）+ 米棕格纹围巾 + 深色直筒牛仔裤 + 白色帆布鞋 + 棕色邮差包。
- **伴生灵**：浩禾整个揣在大衣帽兜里，只露耳朵和蓬松尾巴，一只前爪搭在帽沿——**犬系的具体表现：非要跟着，又懒得走**。
- **构图**：35mm，巷子纵深透视，消失点在右三分线；人物站左三分线回头；头顶挂着一串串晾晒的柿饼，形成暖色重复节奏。
- **光**：巷口尽头低角度金色夕阳，长而冷的蓝影横过地面。**冷暖对撞**是这张的全部意思。
- **易错点**：`wind` 一定要写，否则画面会"摆拍"；柿子要写成 `strings of peeled persimmons drying under the eaves`，不然模型给你一筐水果。

**提示词**
```
a {A} walking down a narrow old-town lane in the last warm minute of a late-autumn afternoon,
turning to look back over her shoulder at the viewer, a paper bag of persimmons in one hand, her
scarf and dry leaves lifted by the wind; strings of peeled persimmons drying under the eaves, stone
walls, a bicycle leaning against a wall; she wears a deep-green duffel coat with toggles, a beige-brown
plaid scarf, dark straight jeans, white canvas sneakers and a brown leather satchel; a {C} tucked
inside her coat hood with only its ears and fluffy tail out, one paw resting on the hood edge, its
tail streaming in the wind; low golden sunlight from the far end of the alley, long cold blue
shadows across the ground, warm persimmon orange against cold shadow tones; 35mm lens, vanishing
point on the right third, subject on the left third, strong backlit rim on her hair; {S}
```

---

### ③ 霜夜河堤 · `wanqiu-19-frost-embankment`

- **一句话**：初霜的夜里她坐在石阶上喝水，浩禾的毛在冷蓝里发一点暖光。
- **服装**：燕麦色 oversize 羊毛长大衣 + 灰连帽卫衣 + 奶白针织帽 + 深色打底裤 + 短靴 + 毛线手套。
- **伴生灵**：浩禾坐在旁边台阶上，尾巴圈住她脚踝，仰头看她。**灵光规则**第一次显形——它身上有一圈和冷蓝场景冲突的暖边光。
- **构图**：24mm 低机位，人物右三分；左半是雾气弥漫的河面；路灯在右上出光斑。
- **光**：蓝调时刻，唯一暖光源是身后那盏钠灯；呼出的白气要看得见。
- **易错点**：`faint warm glow on its fur that does not match the blue scene light` 这句是"灵体感"的开关，别删。删了就是普通夜景。

**提示词**
```
a {A} sitting on wet stone steps of a river embankment at blue hour on the first frosty night of
late autumn, both hands wrapped around a steel thermos, breath misting, looking down at the water;
first frost whitening the step edges, a single warm sodium streetlamp above and behind her, mist
drifting over the black river, far-bank lights blurred; she wears an oversized oatmeal wool overcoat
over a grey hoodie, a cream knit beanie, dark tights, ankle boots and knitted mittens; a {C} sitting
upright on the step beside her, its tail curled around her ankle, looking up at her face, with a
faint warm glow on its fur that does not match the blue scene light; 24mm low angle, subject on the
right third, the misty river filling the left half, lamp flare in the upper right; {S}
```

---

### ④ 无人站台 · `muyu-13-empty-platform`

- **一句话**：拂晓，他站在废站台边看铁轨没入雾里；小耶在椅背上打了个哈欠。
- **服装（本辑独有）**：炭灰羊毛大衣 + 米白麻花针织衫 + 深灰西裤 + 深棕德比靴。**这是全辑唯一一次他穿得"像样"**，和第一辑的军绿夹克拉开。
- **伴生灵**：小耶坐在长椅靠背上，尾巴盘住爪子，打哈欠——**猫系的第一次出场：它在，但它不热情**。
- **构图**：35mm，人物左三分，铁轨向右下延伸进白雾；右侧大片雾留白。
- **光**：没有太阳。冷蓝灰，唯一暖光是檐下那只灯泡。
- **易错点**：别让它变成"第一辑的雾中道口"——那张有栏杆、有列车、有信号灯。这张**什么都没有**，只有空。构图里不要出现列车。

**提示词**
```
a {B} standing alone on the platform of an abandoned rural station at dawn in late autumn, both
hands in his coat pockets, looking down the tracks into thick fog, shoulders slightly hunched against
the cold; wet cracked concrete, rusted rails, weeds pushing through, a broken wooden bench, a single
bare bulb under the eaves; he wears a charcoal wool overcoat over a cream cable-knit sweater, dark
grey trousers and dark brown leather derby boots; a {D} sitting on the back of the bench to his
right, tail wrapped around its paws, yawning, with a faint warm glow on its white fur against the
cold grey scene; cold blue-grey dawn light, fog swallowing the rails, no sun, no train; 35mm lens,
subject on the left third, the rails running away to the right into white fog, a large empty fog
area on the right; {S}
```

---

### ⑤ 银杏参道 · `muyu-14-ginkgo-shrine`

- **一句话**：他蹲在石阶上仰拍树冠，小耶蹲在石灯笼顶上俯视他——一个往上看，一个往下看。
- **服装**：锈橙渔夫毛衣 + 橄榄绿工装裤 + 棕色皮靴 + 帆布背包（单肩）。
- **伴生灵**：小耶蹲在石灯笼顶上，尾巴垂下来，眯眼看他。**猫系的核心动作：占据高处**。
- **构图**：24mm 低机位 + 强对角。人物在左下，石灯笼与狐狸在右上，金色树冠压住上三分之一。
- **光**：逆光，银杏叶透光发亮，有镜头光斑。
- **易错点**：这张最容易画成"人物站在树下拍照"。必须写 `crouching low`、`camera raised to his eye`、`shooting up into a canopy`。

**提示词**
```
a {B} crouching low on the stone approach of a small mountain shrine, camera raised to his eye,
shooting up into a canopy of golden ginkgo, elbows braced on his knees; a carpet of fallen ginkgo
leaves on the worn stone steps, a mossy stone lantern, a torii gate half hidden behind the trunks;
he wears a rust-orange fisherman knit sweater, olive work trousers, brown leather boots and a canvas
backpack slung on one shoulder; a {D} perched on top of the stone lantern above him, tail hanging
down, looking down at him with narrowed eyes, a faint warm glow in its fur; strong golden backlight
through the canopy, leaves glowing translucent, a little lens flare, deep warm shadows; 24mm low
angle with a strong diagonal, subject in the lower left, lantern and fox in the upper right, canopy
filling the top third; {S}
```

---

### ⑥ 夜行列车 · `muyu-15-night-train`

- **一句话**：他把额头靠在车窗上，小耶蜷在腿上；玻璃里那团狐影，位置对不上。
- **服装**：黑连帽卫衣 + 灰羊毛围巾 + 深色牛仔裤 + 黑白帆布鞋。
- **伴生灵**：小耶蜷在他腿上，尾巴盖住鼻尖。**灵体感的最强一击**：窗玻璃上有一只位置错开的狐狸倒影。
- **构图**：50mm，人物右三分，车窗横带占左侧，车厢纵深压暗。
- **光**：冷蓝车厢内光，钠灯橙光条从窗上横掠过他半张脸。
- **易错点**：`a slightly misaligned reflection` 是这个点子本身；写成 `reflection` 模型会给你完美镜像，那就没意思了。若模型反复画错，退一步：让倒影里的人没有狐狸。

**提示词**
```
a {B} sitting alone by the window of a night train, temple leaning against the cold glass, eyes half
closed, the black camera resting on the seat beside him; condensation on the glass, sodium
streetlights and city blocks smeared into horizontal streaks outside, an empty carriage receding into
darkness; he wears a black hoodie, a grey wool scarf, dark jeans and black-and-white canvas sneakers;
a {D} curled on his lap, tail wrapped over its nose, and in the window glass a slightly misaligned
reflection of the fox, with a faint warm glow on its fur; cold blue interior light with warm orange
streaks sliding across his face; 50mm lens, subject on the right third, the window band filling the
left, deep dark negative space in the carriage; {S}
```

---

## 4. 一致性工作流

**先说结论：靠"提示词写死"只能做到 70 分，剩下 30 分必须靠参考图。**

### 4.1 三步法（推荐）

1. **先做定妆照**：用 `01晚秋.png` / `02穆余.png` 当参考，各出一张白底半身正面 + 一张四分之三侧脸。这两张以后就是"人物身份证"。
2. **再拍场景**：用定妆照当角色参考，跑上面六条提示词；参考强度 60–80%（太高会锁死姿势，太低会丢脸）。
3. **回收最像的一张**：六张里挑脸最稳的那张，反过来当参考再重跑其余几张——同一批里互相校准，比一开始就硬套强。

### 4.2 按工具选参数

| 工具 | 做法 |
|---|---|
| **Midjourney v6/v7** | `--cref <晚秋图> --cw 70 --ar 7:4 --style raw`；固定一组 `--sref` 保证画风不漂；种子固定 `--seed` 便于微调 |
| **SDXL / Flux + ComfyUI** | IP-Adapter（face）+ 风格 LoRA（水彩动漫）+ 固定 seed；先跑 1024×585 再 2× 放大 |
| **即梦 / 可灵 / Seedream** | 上传两张参考图，选「角色参考」而非「风格参考」；用 JSON 里的 `zh` 中文提示词，国内模型对中文分镜描述更听话 |
| **Nano Banana / Gemini 图像** | 图 + 文一起发，开头写明："保持图中这位角色完全一致的外貌，只改变场景、服装与光线" |
| **Flux Kontext 类编辑** | 拿第一辑现成图直接改：换衣服、换场景、保留脸——这条路线一致性最高，建议优先试 |

### 4.3 可变量 / 不可变量

- **不可变**：脸型、眼型、刘海走向、创可贴、发带、相机与背带、伴生灵的体型比例与尾尖颜色、画风肌理。
- **可变**：服装、发型扎法、场景、时间、光比、镜头焦段。

> 六张里人物发型允许变扎法（半扎 / 针织帽压住 / 散发），但**脸颊的创可贴和低侧马尾的位置感要保留**——观众认的是这两个点。

---

## 5. 出图验收清单

打完分再放大，别在废图上浪费时间。

- [ ] 脸：和 `01`/`02` 是同一个人的骨相，不是"同款发型的新角色"
- [ ] 晚秋左脸有米色创可贴；穆余身上有黑相机 + 棕背带
- [ ] 浩禾是**橙黄松鼠 + 奶油尾尖**，体型能放进帽兜；不是龙猫、不是狐狸
- [ ] 小耶是**白狐 + 淡杏色尾尖**，体型能蹲在石灯笼上；不是白猫、不是狗
- [ ] 伴生灵只有一只。出现两只就重跑
- [ ] 手：五指、无粘连（拿书、拎袋、握相机三处最容易崩）
- [ ] 留白 ≥ 35%，且集中在人物视线的反侧（能放桌面图标）
- [ ] 纸张肌理在，没有塑料高光、没有 3D 感
- [ ] 每张只有一个暖光源，其余压冷
- [ ] 伴生灵身上有那一圈"不属于场景"的暖光

---

## 6. 交付与命名

- 尺寸：成图 2560×1440（16:9）；竖版可选 1440×2560 另出一套手机壁纸。
- 命名沿用第一辑：`wanqiu-17-…` / `muyu-13-…`，配对图后缀加 `-pair`。
- 导出 sRGB，轻微加 2–4% 纸张颗粒，别过度锐化（水彩感最怕锐）。
- 双屏配对：①④（晨）、②⑤（暮）、③⑥（夜）；左右屏色温一冷一暖，中间接缝才不打架。

---

## 7. 这一辑想说的话

第一辑是"她和他各自在秋天里走"；这一辑把六张排成一天——**同一座城，两个人在同一个清晨、同一个黄昏、同一个深夜，各自和一个别人看不见的东西待着**。
所以他们从头到尾没有同框，但六张放一起，是"同一天"。这就是《共生》的意思。
