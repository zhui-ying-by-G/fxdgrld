#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""分块重采样放大：UltimateSDUpscale + 4x 放大模型，替代 LatentUpscaleBy + Lanczos。

用法:
    python comfy_usdu_upscale.py wq17-v2.png
    python comfy_usdu_upscale.py wq17-v2.png --target 3840x2160 --denoise 0.3

源图从 comfy-out 读取，结果写到当前目录的 <名字>-2k.png。
"""
import argparse
import json
import os
import shutil
import time
import urllib.parse
import urllib.request
import uuid

from PIL import Image

HOST = "http://127.0.0.1:8188"
SRC_DIR = r"D:\壁纸\comfy-out"
INPUT_DIR = r"D:\ComfyUI_windows_portable\ComfyUI\input"
OUT_DIR = r"D:\壁纸"

CKPT = "Illustrious-XL-v2.0.safetensors"
LORA = "watercolor_v1_sdxl.safetensors"
VAE = "sdxl_vae.safetensors"
UPSCALE_MODEL = "4x_foolhardy_Remacri.pth"

NEG = ("lowres, worst quality, low quality, bad anatomy, bad hands, extra digits, "
       "fewer digits, missing fingers, watermark, text, signature, username, "
       "jpeg artifacts, blurry, 3d, cgi, photorealistic, multiple views, "
       "2girls, 2boys, duplicate, chibi, nsfw")


def call(path, payload=None, timeout=300):
    req = urllib.request.Request(HOST + path)
    if payload is not None:
        req = urllib.request.Request(
            HOST + path, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        body = r.read()
    return json.loads(body) if body else {}


def build(src_name, pos, neg, upscale_by, denoise, steps, seed, tile, padding):
    return {
        "ckpt": {"class_type": "CheckpointLoaderSimple",
                 "inputs": {"ckpt_name": CKPT}},
        "lora": {"class_type": "LoraLoader",
                 "inputs": {"model": ["ckpt", 0], "clip": ["ckpt", 1],
                            "lora_name": LORA,
                            "strength_model": 0.75, "strength_clip": 0.75}},
        "pos": {"class_type": "CLIPTextEncode", "inputs": {"text": pos, "clip": ["lora", 1]}},
        "neg": {"class_type": "CLIPTextEncode", "inputs": {"text": neg, "clip": ["lora", 1]}},
        "img": {"class_type": "LoadImage", "inputs": {"image": src_name}},
        "vae": {"class_type": "VAELoader", "inputs": {"vae_name": VAE}},
        "um": {"class_type": "UpscaleModelLoader", "inputs": {"model_name": UPSCALE_MODEL}},
        "usdu": {"class_type": "UltimateSDUpscale", "inputs": {
            "image": ["img", 0],
            "model": ["lora", 0],
            "positive": ["pos", 0],
            "negative": ["neg", 0],
            "vae": ["vae", 0],
            "upscale_by": upscale_by,
            "seed": seed,
            "steps": steps,
            "cfg": 4.5,
            "sampler_name": "dpmpp_2m",
            "scheduler": "karras",
            "denoise": denoise,
            "upscale_model": ["um", 0],
            "mode_type": "Linear",
            "tile_width": tile,
            "tile_height": tile,
            "mask_blur": 12,
            "tile_padding": padding,
            "seam_fix_mode": "Half Tile",
            "seam_fix_denoise": min(denoise + 0.1, 0.6),
            "seam_fix_width": 64,
            "seam_fix_mask_blur": 12,
            "seam_fix_padding": 16,
            "force_uniform_tiles": True,
            "tiled_decode": False,
            "batch_size": 1,
        }},
        "save": {"class_type": "SaveImage",
                 "inputs": {"images": ["usdu", 0], "filename_prefix": "usdu/tmp"}},
    }


def fit(im, target):
    """居中裁到目标比例，再 Lanczos 到目标分辨率。"""
    tw, th = target
    want = tw / th
    w, h = im.size
    if abs(w / h - want) > 1e-3:
        if w / h > want:
            new_w = int(round(h * want))
            left = (w - new_w) // 2
            im = im.crop((left, 0, left + new_w, h))
        else:
            new_h = int(round(w / want))
            top = (h - new_h) // 2
            im = im.crop((0, top, w, top + new_h))
    return im.resize((tw, th), Image.LANCZOS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", help="comfy-out 里的文件名")
    ap.add_argument("--target", default="2560x1440")
    ap.add_argument("--denoise", type=float, default=0.25)
    ap.add_argument("--steps", type=int, default=24)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--tile", type=int, default=768)
    ap.add_argument("--padding", type=int, default=64)
    ap.add_argument("--pos", default="masterpiece, best quality, delicate watercolor, "
                                   "soft light, muted autumn palette")
    ap.add_argument("--neg", default=NEG)
    args = ap.parse_args()

    src_path = os.path.join(SRC_DIR, args.src)
    if not os.path.exists(src_path):
        raise SystemExit("找不到源图: " + src_path)

    tw, th = (int(x) for x in args.target.lower().split("x"))
    base = os.path.splitext(os.path.basename(args.src))[0]

    # 目标比例决定 upscale_by：先放到刚好盖住目标尺寸的最小倍数
    with Image.open(src_path) as im:
        w, h = im.size
    need = max(tw / w, th / h)
    upscale_by = max(1.0, min(4.0, round(need * 1.06, 2)))

    staged = "usdu_" + base + ".png"
    os.makedirs(INPUT_DIR, exist_ok=True)
    shutil.copyfile(src_path, os.path.join(INPUT_DIR, staged))

    t0 = time.time()
    wf = build(staged, args.pos, args.neg, upscale_by, args.denoise, args.steps,
               args.seed, args.tile, args.padding)
    r = call("/prompt", {"prompt": wf, "client_id": uuid.uuid4().hex})
    pid = r.get("prompt_id")
    if not pid:
        raise SystemExit("queue failed: %s" % r)

    while True:
        hist = call("/history/" + pid)
        if pid in hist:
            node = hist[pid]
            st = node.get("status", {})
            if st.get("status_str") == "error":
                raise SystemExit("error: " + json.dumps(st, ensure_ascii=False)[:1500])
            imgs = [i for o in node.get("outputs", {}).values() for i in o.get("images", [])]
            if not imgs:
                raise SystemExit("no image in outputs")
            q = urllib.parse.urlencode({"filename": imgs[0]["filename"],
                                        "subfolder": imgs[0].get("subfolder", ""),
                                        "type": imgs[0].get("type", "output")})
            data = urllib.request.urlopen(HOST + "/view?" + q, timeout=300).read()
            raw = os.path.join(OUT_DIR, "_raw_" + base + ".png")
            with open(raw, "wb") as f:
                f.write(data)
            break
        time.sleep(1.5)

    with Image.open(raw) as im:
        out = fit(im.convert("RGB"), (tw, th))
    dst = os.path.join(OUT_DIR, "%s-%dx%d.png" % (base, tw, th))
    out.save(dst)
    os.remove(raw)
    print("[ok] %s  upscale_by=%.2f  %dx%d  %.1fs" % (dst, upscale_by, tw, th, time.time() - t0))


if __name__ == "__main__":
    main()
