/* ============================================================
   hub.js — 类目页共用的两件小事
   1) 图片加载失败：把这一格换成可读的占位，不留空白
   2) 灯箱：点 .g-shot / .plate 里的图放大看，Esc 或点背景关闭
   没有脚本时页面照常可读：图片本身在 <img> 里，灯箱只是增强。
   ============================================================ */
(function (global) {
  "use strict";

  function fail(img) {
    if (img.dataset.failed) return;
    img.dataset.failed = "1";
    var ph = document.createElement("div");
    ph.className = "img-ph";
    ph.textContent = "图片未能加载 · " + (img.alt || img.src.split("/").pop());
    img.replaceWith(ph);
  }

  function watchImages() {
    Array.prototype.forEach.call(document.querySelectorAll("img[data-watch]"), function (img) {
      img.addEventListener("error", function () { fail(img); });
      if (img.complete && img.naturalWidth === 0) fail(img);
    });
  }

  /* ---------------- 灯箱 ---------------- */
  var box, imgEl, capEl;
  function ensure() {
    if (box) return;
    box = document.createElement("div");
    box.id = "lightbox";
    box.hidden = true;
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-label", "放大查看");
    imgEl = document.createElement("img");
    imgEl.alt = "";
    capEl = document.createElement("div");
    capEl.className = "lb-cap";
    var close = document.createElement("button");
    close.className = "hbtn lb-close";
    close.type = "button";
    close.textContent = "关闭 · Esc";
    close.addEventListener("click", function () { hide(); });
    box.appendChild(imgEl); box.appendChild(capEl); box.appendChild(close);
    box.addEventListener("click", function (e) { if (e.target === box) hide(); });
    document.body.appendChild(box);
  }
  function show(src, alt, cap) {
    ensure();
    imgEl.src = src; imgEl.alt = alt || "";
    capEl.textContent = cap || "";
    box.hidden = false;
    document.body.style.overflow = "hidden";
  }
  function hide() {
    if (!box || box.hidden) return;
    box.hidden = true;
    document.body.style.overflow = "";
  }

  function wireLightbox() {
    Array.prototype.forEach.call(document.querySelectorAll("[data-lb]"), function (node) {
      var img = node.tagName === "IMG" ? node : node.querySelector("img");
      if (!img) return;
      var full = node.getAttribute("data-lb") || img.getAttribute("data-full") || img.currentSrc || img.src;
      var cap = node.getAttribute("data-lb-cap") || (node.closest("figure") ? (node.closest("figure").querySelector("figcaption") || {}).textContent : "");
      node.setAttribute("tabindex", "0");
      node.setAttribute("role", "button");
      node.addEventListener("click", function (e) { e.preventDefault(); show(full, img.alt, cap); });
      node.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); show(full, img.alt, cap); }
      });
    });
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") hide(); });
  }

  function boot() { watchImages(); wireLightbox(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();

  global.HUB = { show: show, hide: hide };
})(window);
