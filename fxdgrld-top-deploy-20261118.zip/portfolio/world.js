/* ============================================================
   world.js — 双王领地 · 可行走世界引擎
   ------------------------------------------------------------
   数据来自 zones.js（REALMS / ZONES），本文件只负责排版与绘制。
   与首页引擎的关键差异：
     · 世界宽度、建筑坐标、地貌交界点全部由 zones 数量算出，
       新增一条记录不需要手改任何数字。
     · 地貌用「两国过渡值」t∈[0,1] 插值，而不是首页的六季色带，
       因此世界变宽不会让已有建筑的色调漂移。
     · 尊重 prefers-reduced-motion；提供文档模式作为纯文字退化路径。
   ============================================================ */

(function () {
  "use strict";

  var R = window.REALMS, Z = window.ZONES, CFG = window.WORLD;
  if (!R || !Z || !CFG) { document.documentElement.classList.add("no-world"); return; }

  /* ---------------- 排版：算出每个 zone 的 x 与世界宽度 ---------------- */
  var SP = CFG.spacing || 1250;
  var REALM_GAP = CFG.realmGap || 1100;
  var PAD = CFG.edgePad || 420;

  var zones = R.map(function (realm, ri) {
    return Z.filter(function (z) { return z.realm === ri; });
  });
  var laid = [];
  var cursor = PAD;
  zones.forEach(function (list, ri) {
    if (ri > 0) cursor += REALM_GAP;
    list.forEach(function (z, i) {
      if (i > 0) cursor += SP;
      var o = {};
      for (var k in z) o[k] = z[k];
      o.ri = ri;
      o.x = cursor;
      laid.push(o);
    });
  });
  var worldW = cursor + PAD;

  /* ---------------- 境界分界：每两个相邻境之间一座界碑 ---------------- */
  var BND = [];
  for (var bi = 0; bi + 1 < R.length; bi++) {
    var west = laid.filter(function (z) { return z.ri === bi; }).pop();
    var east = laid.filter(function (z) { return z.ri === bi + 1; })[0];
    if (!west || !east) continue;
    BND.push({ i: bi, x: (west.x + east.x) / 2, w: Math.max(520, (east.x - west.x) / 2) });
  }

  /* ---------------- 小工具 ---------------- */
  function clamp(v, a, b) { return v < a ? a : v > b ? b : v; }
  function mod(v, m) { return ((v % m) + m) % m; }
  function lerp(a, b, f) { return a + (b - a) * f; }
  function hex2rgb(h) {
    h = h.replace("#", "");
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  function lerpColor(a, b, f) {
    var x = hex2rgb(a), y = hex2rgb(b);
    return "rgb(" + Math.round(lerp(x[0], y[0], f)) + "," +
                    Math.round(lerp(x[1], y[1], f)) + "," +
                    Math.round(lerp(x[2], y[2], f)) + ")";
  }
  function lerpRGB(a, b, f) {
    var x = a.split(","), y = b.split(",");
    return Math.round(lerp(+x[0], +y[0], f)) + "," +
           Math.round(lerp(+x[1], +y[1], f)) + "," +
           Math.round(lerp(+x[2], +y[2], f));
  }
  /* 位置 → 地貌分段：境域内纯色调，交界处按 smoothstep 过渡。
     返回 { a, b, t }：a 境向 b 境过渡 t∈[0,1]；纯境时 a===b、t===0。 */
  function smooth(t) { return t * t * (3 - 2 * t); }
  function segAt(x) {
    var i = 0;
    while (i < BND.length && x >= BND[i].x) i++;
    var inB = i > 0 ? BND[i - 1] : null;
    var outB = i < BND.length ? BND[i] : null;
    if (inB) {
      var d0 = (x - (inB.x - inB.w)) / (2 * inB.w);
      if (d0 < 1) return { a: i - 1, b: i, t: smooth(clamp(d0, 0, 1)) };
    }
    if (outB) {
      var d1 = (x - (outB.x - outB.w)) / (2 * outB.w);
      if (d1 >= 0) return { a: i, b: i + 1, t: smooth(clamp(d1, 0, 1)) };
    }
    return { a: i, b: i, t: 0 };
  }
  /* 位置所属的境（过渡带取较近的一边） */
  function realmAt(x) {
    var s = segAt(x);
    return s.t < 0.5 ? s.a : s.b;
  }
  /* 确定性伪随机：同一 seed 每次刷新地形一致 */
  function rand(seed) {
    var s = seed >>> 0;
    return function () {
      s = (s * 1664525 + 1013904223) >>> 0;
      return s / 4294967296;
    };
  }

  var HEXKEYS = [], NUMKEYS = [], RGBKEYS = ["glow", "haze", "tint"];
  (function () {
    var p = R[0].pal;
    for (var k in p) {
      if (RGBKEYS.indexOf(k) >= 0) continue;
      if (typeof p[k] === "number") NUMKEYS.push(k); else HEXKEYS.push(k);
    }
  })();

  var PC = {};
  function updatePal(x) {
    var s = segAt(x), A = R[s.a].pal, B = R[s.b].pal, f = s.t;
    var mix = function (k) { return B[k] === undefined ? A[k] : B[k]; };
    for (var i = 0; i < HEXKEYS.length; i++) { var k = HEXKEYS[i]; PC[k] = lerpColor(A[k], mix(k), f); }
    for (var j = 0; j < RGBKEYS.length; j++) { var k2 = RGBKEYS[j]; PC[k2] = lerpRGB(A[k2], mix(k2), f); }
    for (var n = 0; n < NUMKEYS.length; n++) { var k3 = NUMKEYS[n]; PC[k3] = lerp(A[k3], mix(k3), f); }
    PC.f = f;
    PC.ri = f < 0.5 ? s.a : s.b;
  }

  /* ---------------- 画布 ---------------- */
  var cv = document.getElementById("game");
  var ctx = cv.getContext ? cv.getContext("2d") : null;
  if (!ctx) { document.documentElement.classList.add("no-world"); enableDoc(); return; }

  var vw = 0, vh = 0, dpr = 1, u = 1, groundY = 0;
  function resize() {
    dpr = Math.min(2, window.devicePixelRatio || 1);
    vw = window.innerWidth; vh = window.innerHeight;
    cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
    cv.style.width = vw + "px"; cv.style.height = vh + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = false;
    u = clamp(Math.min(vw / 900, vh / 560), 0.7, 1.5);
    groundY = Math.round(vh - clamp(vh * 0.2, 108, 196));
    buildStars();
  }

  var reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ---------------- 玩家 ---------------- */
  var player = { x: laid[0].x + 40, dir: 1, walk: 0, speed: 460, bob: 0 };
  var cam = { x: 0, vel: 0 };
  var target = null;

  /* ---------------- 星空 ---------------- */
  /* 星星铺满一屏宽度后循环复用：世界再宽，天穹也只有一片。 */
  var stars = [], STAR_SPAN = 1400;
  function buildStars() {
    var n = rand(90210), out = [];
    STAR_SPAN = vw + 140;
    for (var i = 0; i < 110; i++) {
      out.push({ x: n() * STAR_SPAN, y: n() * vh * 0.55, s: n() < 0.85 ? 1 : 2, p: n() * 6.28 });
    }
    stars = out;
  }

  /* ---------------- 远景地形（确定性生成一次） ---------------- */
  var ridge = [];
  (function () {
    var defs = [
      { step: 190, amp: 130, base: 0.40 },
      { step: 150, amp: 96, base: 0.30 },
      { step: 120, amp: 70, base: 0.20 },
    ];
    defs.forEach(function (d, li) {
      var n = rand(1000 + li * 77), pts = [];
      for (var x = -400; x < worldW + 1200; x += d.step) {
        pts.push({ x: x, y: -(d.amp * (0.45 + n() * 0.9)) });
      }
      ridge.push({ pts: pts, base: d.base, par: 0.12 + li * 0.1, key: ["ridgeFar", "ridgeMid", "ridgeNear"][li] });
    });
  })();

  var hills = [];
  (function () {
    [{ step: 260, amp: 54, par: 0.42, base: 0.17, key: "hillFar" },
     { step: 210, amp: 40, par: 0.56, base: 0.09, key: "hillNear" }].forEach(function (d, li) {
      var n = rand(400 + li * 31), pts = [];
      for (var x = -400; x < worldW + 1200; x += d.step) {
        pts.push({ x: x, y: -(d.amp * (0.5 + n())) });
      }
      hills.push({ pts: pts, par: d.par, base: d.base, key: d.key });
    });
  })();

  var btrees = [];
  (function () {
    var n = rand(7717);
    for (var x = -200; x < worldW + 800; x += 90 + n() * 110) {
      var nearZone = laid.some(function (z) { return Math.abs(z.x - x) < 240; });
      if (nearZone) continue;
      btrees.push({ x: x, s: 0.55 + n() * 0.6, k: n() < 0.5 ? 0 : 1 });
    }
  })();

  /* ---------------- 粒子天气 ---------------- */
  var parts = [], motes = [];
  function mk(cfg, n, kind, count) {
    for (var i = 0; i < count; i++) {
      var list = kind === "m" ? motes : parts;
      list.push({
        x: n() * vw, y: n() * vh,
        vx: (n() - 0.5) * 20, vy: 12 + n() * cfg.fall,
        s: cfg.size * (0.6 + n() * 0.8), ph: n() * 6.28,
        c: i % cfg.cols.length, k: kind,
      });
    }
  }

  /* 越境时换天气：按当前境的粒子数量与配色重建下落粒子。
     粒子坐标依赖 vw/vh，所以首次播种必须等 resize() 之后。 */
  var weatherRi = -1;
  function syncWeather(ri) {
    if (ri === weatherRi) return;
    weatherRi = ri;
    var cfg = R[ri].weather;
    parts.length = 0;
    mk(cfg, rand(55 + ri * 13), "p", cfg.rate * 6);
  }
  function seedParticles() {
    weatherRi = -1;
    syncWeather(realmAt(player.x));
    motes.length = 0;
    mk({ cols: ["#fff"], size: 2, fall: -10 }, rand(33), "m", 120);
  }

  function stepParticles(dt, t) {
    if (reduce) return;
    syncWeather(realmAt(player.x));
    var cfg = R[weatherRi].weather;
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      p.y += p.vy * dt * 0.55;
      p.x += (Math.sin(t * 1.1 + p.ph) * cfg.drift + p.vx) * dt * 0.5 - cam.vel * 0.15;
      if (p.y > vh + 10) { p.y = -12; p.x = Math.random() * (vw + 80) - 40; p.c = (Math.random() * cfg.cols.length) | 0; }
      if (p.x < -40) p.x = vw + 30; else if (p.x > vw + 40) p.x = -30;
    }
    for (var j = 0; j < motes.length; j++) {
      var m = motes[j];
      m.y -= (6 + Math.sin(t * 0.7 + m.ph) * 5) * dt * 0.6;
      m.x += Math.sin(t * 0.5 + m.ph * 1.7) * 8 * dt;
      if (m.y < -10) { m.y = vh + 8; m.x = Math.random() * vw; }
    }
  }

  /* ---------------- 像素绘制基础 ---------------- */
  function R0(x, y, w, h, col) {
    ctx.fillStyle = col;
    ctx.fillRect(Math.round(x), Math.round(y), Math.max(1, Math.round(w)), Math.max(1, Math.round(h)));
  }
  function band(layer, key, yOff) {
    var L = layer, col = PC[key];
    ctx.fillStyle = col;
    ctx.beginPath();
    var ox = -cam.x * L.par;
    ctx.moveTo(ox + L.pts[0].x, vh * (1 - L.base) + yOff + L.pts[0].y);
    for (var i = 0; i < L.pts.length; i++) {
      var p = L.pts[i];
      ctx.lineTo(ox + p.x, vh * (1 - L.base) + yOff + p.y);
    }
    ctx.lineTo(ox + L.pts[L.pts.length - 1].x, vh + 40);
    ctx.closePath();
    ctx.fill();
  }

  /* ---------------- 建筑：像素结构绘制 ---------------- */
  var DRAW = {
    /* 王座：台基 + 高背椅 + 华盖 */
    throne: function (sx, b, tone) {
      var w = 116 * u, h = 132 * u;
      R0(sx - w / 2 - 14 * u, b - 12 * u, w + 28 * u, 12 * u, PC.stoneDeep);
      R0(sx - w / 2 - 8 * u, b - 22 * u, w + 16 * u, 10 * u, PC.stone);
      R0(sx - w / 2, b - h, w, h - 20 * u, tone.deep);
      R0(sx - w / 2 + 10 * u, b - h + 16 * u, w - 20 * u, h - 54 * u, tone.mid);
      R0(sx - w / 2 + 18 * u, b - 40 * u, w - 36 * u, 26 * u, tone.hi);
      /* 靠背尖顶 */
      for (var i = 0; i < 5; i++) {
        var px = sx - w / 2 + 6 * u + i * (w - 12 * u) / 4;
        R0(px, b - h - 14 * u, 8 * u, 16 * u, tone.hi);
      }
      /* 华盖 */
      R0(sx - w / 2 - 22 * u, b - h - 40 * u, w + 44 * u, 10 * u, tone.deep);
      R0(sx - w / 2 - 22 * u, b - h - 30 * u, 6 * u, 30 * u, PC.stoneDeep);
      R0(sx + w / 2 + 16 * u, b - h - 30 * u, 6 * u, 30 * u, PC.stoneDeep);
      glow(sx, b - h - 6 * u, 70 * u, tone.hi, 0.5);
    },
    /* 议事厅：长桌 + 旗帜 */
    hall: function (sx, b, tone) {
      var w = 180 * u, h = 104 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - h + 10 * u, w - 16 * u, h - 18 * u, PC.stone);
      roof(sx, b - h, w + 26 * u, 34 * u, tone.deep, tone.mid);
      for (var i = 0; i < 4; i++) {
        R0(sx - w / 2 + 22 * u + i * 44 * u, b - h + 26 * u, 24 * u, 34 * u, "#1a1524");
        R0(sx - w / 2 + 22 * u + i * 44 * u, b - h + 26 * u, 24 * u, 6 * u, tone.hi);
      }
      R0(sx - 40 * u, b - 30 * u, 80 * u, 10 * u, tone.mid);
      R0(sx - 34 * u, b - 20 * u, 6 * u, 20 * u, tone.deep);
      R0(sx + 28 * u, b - 20 * u, 6 * u, 20 * u, tone.deep);
      flag(sx - w / 2 - 6 * u, b - h - 26 * u, tone.hi);
      flag(sx + w / 2 + 6 * u, b - h - 26 * u, tone.hi);
    },
    /* 典章阁：高柜 + 书格 */
    library: function (sx, b, tone) {
      var w = 150 * u, h = 150 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 6 * u, b - h + 6 * u, w - 12 * u, h - 12 * u, "#241c16");
      for (var r = 0; r < 4; r++) {
        for (var c = 0; c < 5; c++) {
          var bx = sx - w / 2 + 12 * u + c * 26 * u, by = b - h + 14 * u + r * 32 * u;
          var n = rand(r * 5 + c)();
          R0(bx, by, 20 * u, 24 * u, n < 0.34 ? tone.deep : n < 0.67 ? tone.mid : "#5c4a6e");
          R0(bx, by, 20 * u, 4 * u, tone.hi);
        }
      }
      roof(sx, b - h, w + 20 * u, 26 * u, tone.deep, tone.mid);
      glow(sx, b - 24 * u, 46 * u, tone.hi, 0.35);
    },
    /* 演武场：栅栏 + 沙盘 + 靶 */
    drill: function (sx, b, tone) {
      var w = 172 * u;
      R0(sx - w / 2, b - 16 * u, w, 16 * u, PC.dirt);
      R0(sx - w / 2, b - 20 * u, w, 5 * u, PC.dirtLine);
      for (var i = 0; i < 8; i++) {
        var fx = sx - w / 2 + 8 * u + i * 21 * u;
        R0(fx, b - 46 * u, 6 * u, 32 * u, "#6b4a30");
        if (i < 7) R0(fx + 6 * u, b - 40 * u, 15 * u, 5 * u, "#7d5939");
      }
      R0(sx - 30 * u, b - 60 * u, 60 * u, 34 * u, PC.stone);
      R0(sx - 26 * u, b - 56 * u, 52 * u, 26 * u, tone.mid);
      for (var k = 0; k < 5; k++) R0(sx - 20 * u + k * 10 * u, b - 50 * u, 4 * u, 4 * u, tone.hi);
      flag(sx, b - 104 * u, tone.hi);
      R0(sx - 3 * u, b - 96 * u, 6 * u, 40 * u, "#6b4a30");
    },
    /* 史阁：巨卷 + 竹简架 */
    scrollhouse: function (sx, b, tone) {
      var w = 156 * u, h = 118 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - h + 8 * u, w - 16 * u, h - 16 * u, "#2b2418");
      /* 横放的卷轴 */
      R0(sx - 58 * u, b - h - 26 * u, 116 * u, 30 * u, "#e8dcc0");
      R0(sx - 58 * u, b - h - 26 * u, 10 * u, 30 * u, tone.deep);
      R0(sx + 48 * u, b - h - 26 * u, 10 * u, 30 * u, tone.deep);
      for (var i = 0; i < 4; i++) R0(sx - 38 * u, b - h - 18 * u + i * 6 * u, 76 * u, 2 * u, "#8b7a5a");
      for (var c = 0; c < 3; c++) {
        var cx = sx - 46 * u + c * 46 * u;
        R0(cx, b - h + 22 * u, 34 * u, h - 44 * u, "#3d3220");
        for (var r = 0; r < 5; r++) R0(cx + 4 * u, b - h + 30 * u + r * 14 * u, 26 * u, 9 * u, r % 2 ? tone.mid : tone.deep);
      }
      glow(sx, b - h - 10 * u, 60 * u, "#fff2cf", 0.3);
    },
    /* 书斋：窗 + 灯 + 案 */
    study: function (sx, b, tone) {
      var w = 148 * u, h = 96 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 7 * u, b - h + 7 * u, w - 14 * u, h - 14 * u, "#26202c");
      roof(sx, b - h, w + 24 * u, 32 * u, tone.deep, tone.mid);
      /* 亮窗 */
      R0(sx - 34 * u, b - h + 24 * u, 44 * u, 38 * u, "#0f1420");
      R0(sx - 30 * u, b - h + 28 * u, 36 * u, 30 * u, "#ffe9a8");
      R0(sx - 12 * u, b - h + 28 * u, 4 * u, 30 * u, "#0f1420");
      glow(sx - 12 * u, b - h + 42 * u, 62 * u, "#ffe9a8", 0.4);
      R0(sx + 20 * u, b - 44 * u, 42 * u, 8 * u, tone.mid);
      R0(sx + 26 * u, b - 36 * u, 6 * u, 30 * u, tone.deep);
      R0(sx + 50 * u, b - 36 * u, 6 * u, 30 * u, tone.deep);
      R0(sx + 34 * u, b - 62 * u, 4 * u, 18 * u, "#c9c2b0");
    },
    /* 信箱：立柱 + 箱身 + 旗 */
    mailbox: function (sx, b, tone) {
      var w = 62 * u, h = 86 * u;
      R0(sx - 10 * u, b - h + 26 * u, 20 * u, h - 26 * u, PC.stoneDeep);
      R0(sx - w / 2, b - h, w, 60 * u, tone.deep);
      R0(sx - w / 2 + 5 * u, b - h + 5 * u, w - 10 * u, 30 * u, tone.mid);
      R0(sx - w / 2 - 4 * u, b - h - 8 * u, w + 8 * u, 12 * u, tone.hi);
      R0(sx - 20 * u, b - h + 14 * u, 40 * u, 5 * u, "#1a1524");
      glow(sx, b - h - 2 * u, 40 * u, tone.hi, 0.4);
    },
    /* 界碑：碑身 + 两侧境色条 */
    stele: function (sx, b, riA, riB) {
      var w = 42 * u, h = 108 * u;
      R0(sx - w / 2 - 10 * u, b - 10 * u, w + 20 * u, 10 * u, PC.stoneDeep);
      R0(sx - w / 2, b - h, w, h, PC.stone);
      R0(sx - w / 2, b - h, w / 2, h, "rgba(255,255,255,.07)");
      R0(sx - w / 2 - 6 * u, b - h - 6 * u, w + 12 * u, 12 * u, PC.stoneDeep);
      var half = Math.round(w / 2);
      R0(sx - half + 8 * u, b - h + 18 * u, w - 16 * u, 4 * u, R[riA].pal.accent);
      R0(sx - half + 8 * u, b - h + 28 * u, w - 16 * u, 4 * u, R[riB].pal.accent);
      R0(sx - 3 * u, b - h + 40 * u, 6 * u, h - 58 * u, "rgba(0,0,0,.35)");
    },
    /* ── 以下为六境扩展建筑 ─────────────────────────────── */

    /* 奠基：台基已夯好、木架已立、旗还没挂 —— 尚未开放的领地 */
    found: function (sx, b, tone) {
      var w = 150 * u;
      R0(sx - w / 2, b - 18 * u, w, 18 * u, PC.stoneDeep);
      R0(sx - w / 2 + 6 * u, b - 26 * u, w - 12 * u, 8 * u, PC.stone);
      var post = [-64, -22, 22, 64];
      for (var i = 0; i < post.length; i++) {
        R0(sx + post[i] * u, b - 108 * u, 6 * u, 90 * u, "#6b4a30");
      }
      R0(sx - 64 * u, b - 100 * u, 134 * u, 6 * u, "#7d5939");
      R0(sx - 64 * u, b - 62 * u, 134 * u, 6 * u, "#5c3f28");
      R0(sx, b - 152 * u, 5 * u, 50 * u, "#6b4a30");
      R0(sx - 5 * u, b - 156 * u, 15 * u, 6 * u, tone.deep);
      R0(sx - 46 * u, b - 54 * u, 46 * u, 22 * u, "#3d3220");
      R0(sx - 43 * u, b - 51 * u, 40 * u, 16 * u, tone.mid);
      glow(sx, b - 34 * u, 48 * u, tone.hi, 0.18);
    },
    /* 长廊：矮墙 + 三个上射灯的画框 */
    gallery: function (sx, b, tone) {
      var w = 210 * u, h = 92 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - h + 8 * u, w - 16 * u, h - 16 * u, "#221d28");
      R0(sx - w / 2 - 10 * u, b - h - 12 * u, w + 20 * u, 12 * u, tone.deep);
      R0(sx - w / 2 - 10 * u, b - h - 4 * u, w + 20 * u, 4 * u, tone.mid);
      for (var i = 0; i < 3; i++) {
        var fx = sx - 78 * u + i * 62 * u, fy = b - h + 24 * u;
        R0(fx - 4 * u, fy - 4 * u, 56 * u, 44 * u, tone.hi);
        R0(fx, fy, 48 * u, 36 * u, i % 2 ? "#3a4a6a" : "#5a4030");
        R0(fx, fy + 22 * u, 48 * u, 14 * u, i % 2 ? "#26364e" : "#3d2c22");
        R0(fx + 9 * u, fy + 6 * u, 11 * u, 8 * u, "rgba(255,240,200,.55)");
        R0(fx + 20 * u, b - h + 10 * u, 8 * u, 6 * u, tone.mid);
        glow(fx + 24 * u, fy + 14 * u, 34 * u, "#fff2cf", 0.26);
      }
      R0(sx - 26 * u, b - 8 * u, 52 * u, 8 * u, PC.stone);
    },
    /* 光盒：玻璃罩里立着一座会亮的微缩景观（动态壁纸） */
    lightbox: function (sx, b, tone) {
      var w = 104 * u, h = 132 * u;
      R0(sx - w / 2 - 12 * u, b - 16 * u, w + 24 * u, 16 * u, PC.stoneDeep);
      R0(sx - w / 2 - 6 * u, b - 24 * u, w + 12 * u, 8 * u, PC.stone);
      R0(sx - w / 2, b - h, w, h - 24 * u, "#141824");
      for (var i = 0; i < 4; i++) {
        var mh = (18 + i * 12) * u;
        R0(sx - w / 2 + 8 * u + i * 22 * u, b - 24 * u - mh, 20 * u, mh, i % 2 ? tone.deep : tone.mid);
      }
      R0(sx - w / 2 + 6 * u, b - 44 * u, w - 12 * u, 6 * u, tone.hi);
      R0(sx - w / 2 - 5 * u, b - h - 5 * u, w + 10 * u, 5 * u, tone.hi);
      R0(sx - w / 2 - 5 * u, b - 24 * u, w + 10 * u, 4 * u, tone.hi);
      R0(sx - w / 2 - 5 * u, b - h - 5 * u, 5 * u, h - 19 * u, tone.mid);
      R0(sx + w / 2, b - h - 5 * u, 5 * u, h - 19 * u, tone.mid);
      glow(sx, b - h / 2 - 20 * u, 110 * u, tone.hi, 0.4);
    },
    /* 分镜墙：钉线 + 2×3 格分镜纸 */
    board: function (sx, b, tone) {
      var w = 196 * u, h = 116 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 10 * u, b - h + 10 * u, w - 20 * u, h - 20 * u, "#20242e");
      R0(sx - w / 2, b - h + 6 * u, w, 2 * u, tone.deep);
      for (var r = 0; r < 2; r++) {
        for (var c = 0; c < 3; c++) {
          var fx = sx - w / 2 + 22 * u + c * 54 * u, fy = b - h + 20 * u + r * 42 * u;
          R0(fx, fy, 46 * u, 32 * u, "#e8e0d0");
          R0(fx + 2 * u, fy + 2 * u, 42 * u, 20 * u, (r + c) % 2 ? "#7d93a8" : "#4c5a6e");
          R0(fx + 2 * u, fy + 24 * u, 42 * u, 5 * u, "#c9c2b0");
          R0(fx, fy, 46 * u, 2 * u, tone.hi);
        }
      }
      R0(sx - w / 2 - 10 * u, b - 30 * u, 20 * u, 30 * u, PC.stone);
      R0(sx - w / 2 - 14 * u, b - 36 * u, 28 * u, 6 * u, tone.mid);
      glow(sx, b - 60 * u, 80 * u, tone.hi, 0.2);
    },
    /* 乐台：共鸣箱 + 声波 */
    stage: function (sx, b, tone) {
      var w = 176 * u;
      R0(sx - w / 2, b - 22 * u, w, 22 * u, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - 30 * u, w - 16 * u, 8 * u, tone.deep);
      R0(sx - 34 * u, b - 96 * u, 68 * u, 66 * u, "#3d3220");
      R0(sx - 28 * u, b - 90 * u, 56 * u, 54 * u, tone.mid);
      R0(sx - 10 * u, b - 74 * u, 20 * u, 20 * u, "#1a1524");
      R0(sx - 3 * u, b - 130 * u, 6 * u, 40 * u, "#2b2338");
      for (var i = 0; i < 5; i++) {
        var ww = (28 + i * 22) * u;
        R0(sx - ww / 2, b - 142 * u - i * 9 * u, ww, 4 * u, tone.hi);
      }
      glow(sx, b - 70 * u, 86 * u, tone.hi, 0.28);
    },
    /* 讲台：黑板 + 讲桌 + 一摞成卷 */
    lectern: function (sx, b, tone) {
      var w = 168 * u, h = 108 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - h + 8 * u, w - 16 * u, h - 16 * u, "#232b26");
      R0(sx - 62 * u, b - h + 18 * u, 100 * u, 56 * u, "#1d2a24");
      R0(sx - 62 * u, b - h + 18 * u, 100 * u, 3 * u, tone.hi);
      for (var i = 0; i < 4; i++) {
        R0(sx - 54 * u, b - h + 30 * u + i * 11 * u, (70 - i * 16) * u, 3 * u, "rgba(232,224,208,.6)");
      }
      R0(sx + 44 * u, b - 56 * u, 40 * u, 8 * u, tone.deep);
      R0(sx + 52 * u, b - 48 * u, 24 * u, 48 * u, "#4a3a28");
      R0(sx + 46 * u, b - 66 * u, 34 * u, 4 * u, "#e8e0d0");
      R0(sx + 48 * u, b - 70 * u, 30 * u, 4 * u, "#d8cfba");
      glow(sx - 12 * u, b - 58 * u, 52 * u, tone.hi, 0.22);
    },
    /* 工棚：天窗 + 画架 + 工具柜（生成工作流 / 制作间） */
    atelier: function (sx, b, tone) {
      var w = 156 * u, h = 88 * u;
      R0(sx - w / 2, b - h, w, h, PC.stoneDeep);
      R0(sx - w / 2 + 8 * u, b - h + 10 * u, w - 16 * u, h - 18 * u, "#2a2418");
      roof(sx, b - h, w + 20 * u, 30 * u, tone.deep, PC.stone);
      R0(sx - 22 * u, b - h - 22 * u, 44 * u, 14 * u, "#ffe9a8");
      glow(sx, b - h - 12 * u, 70 * u, "#ffe9a8", 0.3);
      R0(sx - 46 * u, b - 72 * u, 44 * u, 32 * u, "#e8dcc0");
      R0(sx - 42 * u, b - 68 * u, 36 * u, 24 * u, tone.mid);
      R0(sx - 32 * u, b - 40 * u, 5 * u, 40 * u, "#6b4a30");
      R0(sx - 12 * u, b - 40 * u, 5 * u, 40 * u, "#6b4a30");
      R0(sx + 22 * u, b - 46 * u, 48 * u, 46 * u, "#3d3220");
      for (var d = 0; d < 3; d++) {
        R0(sx + 28 * u, b - 40 * u + d * 13 * u, 36 * u, 8 * u, d === 1 ? tone.hi : tone.deep);
      }
    },
  };

  function roof(sx, top, w, h, deep, mid) {
    var steps = 7;
    for (var i = 0; i < steps; i++) {
      var f = i / (steps - 1);
      var rw = w * (1 - f * 0.78);
      R0(sx - rw / 2, top - h + i * (h / steps), rw, h / steps + 1, i % 2 ? mid : deep);
    }
    R0(sx - w / 2, top - 3 * u, w, 5 * u, deep);
  }
  function flag(sx, sy, col) {
    var t = now * 2.2;
    for (var i = 0; i < 4; i++) {
      R0(sx + 4 * u + i * 6 * u, sy + 2 * u + Math.sin(t + i * 0.7) * 2 * u, 6 * u, 14 * u, col);
    }
    R0(sx, sy - 6 * u, 4 * u, 30 * u, "#6b4a30");
  }
  function glow(sx, sy, r, col, a) {
    if (reduce) return;
    var g = ctx.createRadialGradient(sx, sy, 0, sx, sy, r);
    g.addColorStop(0, hexA(col, a));
    g.addColorStop(1, hexA(col, 0));
    ctx.fillStyle = g;
    ctx.fillRect(sx - r, sy - r, r * 2, r * 2);
  }
  function hexA(c, a) {
    if (c.charAt(0) === "#") { var v = hex2rgb(c); return "rgba(" + v[0] + "," + v[1] + "," + v[2] + "," + a + ")"; }
    if (c.indexOf("rgb(") === 0) return c.replace("rgb(", "rgba(").replace(")", "," + a + ")");
    return c;
  }

  function tree(sx, b, s, kind) {
    var h = 70 * s * u, w = 40 * s * u;
    R0(sx - 4 * s * u, b - h * 0.42, 8 * s * u, h * 0.42, PC.trunk);
    if (kind === 0) {
      for (var i = 0; i < 3; i++) {
        var cw = w * (1 - i * 0.24);
        R0(sx - cw / 2, b - h + i * h * 0.2, cw, h * 0.26, i === 2 ? PC.treeNear : PC.treeMid);
      }
    } else {
      R0(sx - w / 2, b - h, w, h * 0.7, PC.treeMid);
      R0(sx - w / 2 + 5 * s * u, b - h - 6 * s * u, w - 10 * s * u, h * 0.3, PC.treeFar);
      R0(sx - w / 2 - 5 * s * u, b - h + h * 0.3, 6 * s * u, h * 0.3, PC.treeNear);
      R0(sx + w / 2 - 1 * s * u, b - h + h * 0.24, 6 * s * u, h * 0.32, PC.treeNear);
    }
  }

  function playerSprite(sx, b) {
    var s = u * 1.05, bob = reduce ? 0 : Math.sin(player.walk * 9) * 1.6 * s;
    var top = b - 52 * s + bob;
    var accent = R[PC.ri].pal;
    ctx.save();
    ctx.globalAlpha = 0.28;
    ctx.fillStyle = "#000";
    ctx.beginPath();
    ctx.ellipse(sx, b + 2 * s, 13 * s, 4 * s, 0, 0, 6.283);
    ctx.fill();
    ctx.restore();
    /* 腿 */
    var sw = reduce ? 0 : Math.sin(player.walk * 9) * 5 * s;
    R0(sx - 6 * s + sw, top + 30 * s, 5 * s, 20 * s, "#3a2f4a");
    R0(sx + 1 * s - sw, top + 30 * s, 5 * s, 20 * s, "#2f2740");
    /* 袍 */
    R0(sx - 9 * s, top + 12 * s, 18 * s, 22 * s, accent.accent);
    R0(sx - 9 * s, top + 12 * s, 18 * s, 5 * s, accent.accentText);
    R0(sx - 11 * s, top + 16 * s, 3 * s, 14 * s, "#e8e0d0");
    R0(sx + 8 * s, top + 16 * s, 3 * s, 14 * s, "#e8e0d0");
    /* 头 */
    R0(sx - 7 * s, top, 14 * s, 13 * s, "#f2e2c8");
    R0(sx - 8 * s, top - 3 * s, 16 * s, 6 * s, "#2b2338");
    R0(sx - 8 * s, top - 3 * s, 16 * s, 2 * s, accent.accent);
    var ex = player.dir > 0 ? sx + 1 * s : sx - 5 * s;
    R0(ex, top + 5 * s, 2 * s, 2 * s, "#2b2338");
    R0(ex + 4 * s, top + 5 * s, 2 * s, 2 * s, "#2b2338");
  }

  /* ---------------- 渲染 ---------------- */
  var now = 0;
  function render() {
    var t = now;
    updatePal(player.x);
    /* 天空 */
    var g = ctx.createLinearGradient(0, 0, 0, groundY + 40);
    g.addColorStop(0, PC.skyTop);
    g.addColorStop(0.52, PC.skyMid);
    g.addColorStop(1, PC.skyLow);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, vw, vh);

    /* 星 */
    if (PC.starA > 0.02) {
      for (var i = 0; i < stars.length; i++) {
        var s = stars[i];
        var sx = mod(s.x - cam.x * 0.08, STAR_SPAN) - 70;
        var tw = reduce ? 1 : 0.6 + Math.sin(t * 1.6 + s.p) * 0.4;
        R0(sx, s.y, s.s, s.s, "rgba(255,255,255," + (PC.starA * tw * 0.85).toFixed(3) + ")");
      }
      /* 月 */
      var mx = vw * 0.76, my = vh * 0.16;
      if (PC.moonA > 0.05) {
        glow(mx, my, 66 * u, "#e8f0ff", PC.moonA * 0.28);
        R0(mx - 15 * u, my - 15 * u, 30 * u, 30 * u, "rgba(240,246,255," + (PC.moonA * 0.92).toFixed(2) + ")");
        R0(mx - 19 * u, my - 11 * u, 8 * u, 22 * u, "rgba(240,246,255," + (PC.moonA * 0.5).toFixed(2) + ")");
      }
    }
    /* 日 */
    if (PC.sunA > 0.05) {
      var sunX = vw * 0.24, sunY = vh * PC.sunY;
      glow(sunX, sunY, 150 * u, "#ffdf9a", PC.sunA * 0.4);
      ctx.fillStyle = "rgba(255,236,180," + (PC.sunA * 0.9).toFixed(2) + ")";
      ctx.beginPath(); ctx.arc(sunX, sunY, 20 * u, 0, 6.283); ctx.fill();
    }

    ridge.forEach(function (L, i) { band(L, L.key, i * 8 * u); });
    hills.forEach(function (L, i) { band(L, L.key, i * 6 * u); });

    /* 背景树 */
    var par = 0.72;
    for (var b0 = 0; b0 < btrees.length; b0++) {
      var tr = btrees[b0], sx = tr.x - cam.x * par;
      if (sx < -90 || sx > vw + 90) continue;
      tree(sx, groundY - 30 * u + (1 - tr.s) * 12 * u, tr.s * 0.8, tr.k);
    }

    /* 地面 */
    R0(0, groundY - 6 * u, vw, 8 * u, PC.grassTop);
    R0(0, groundY + 2 * u, vw, vh - groundY, PC.grass);
    R0(0, groundY + 34 * u, vw, vh, PC.grassDeep);
    var py = groundY + 44 * u;
    R0(0, py, vw, 30 * u, PC.pathEdge);
    R0(0, py + 4 * u, vw, 22 * u, PC.path);
    R0(0, py + 30 * u, vw, vh - py, PC.dirt);
    for (var d = 0; d < 26; d++) {
      var dx = ((d * 137 - cam.x) % (vw + 140)) - 70;
      R0(dx, py + 8 * u, 22 * u, 4 * u, PC.dirtLine);
    }

    /* 建筑 */
    for (var z = 0; z < laid.length; z++) {
      var zo = laid[z], zx = zo.x - cam.x;
      if (zx < -260 || zx > vw + 260) continue;
      if (zo.kind === "info") continue;
      var tone = toneOf(zo.ri);
      var near = Math.abs(zo.x - player.x) < 190;
      if (near && !reduce) glow(zx, groundY - 40 * u, 120 * u, R[zo.ri].pal.accentText, 0.18);
      (DRAW[zo.draw] || DRAW.hall)(zx, groundY + 20 * u, tone);
      sign(zx, groundY + 20 * u, zo);
    }
    /* 界碑：每道境界一座 */
    for (var bd = 0; bd < BND.length; bd++) {
      var bsx = BND[bd].x - cam.x;
      if (bsx > -140 && bsx < vw + 140) DRAW.stele(bsx, groundY + 20 * u, bd, bd + 1);
    }

    /* 玩家 */
    playerSprite(player.x - cam.x, groundY + 62 * u);

    /* 天气粒子 */
    var wcfg = R[PC.ri].weather;
    ctx.globalAlpha = 0.85;
    for (var p = 0; p < parts.length; p++) {
      var q = parts[p];
      ctx.fillStyle = wcfg.cols[q.c];
      if (wcfg.type === "petal") {
        R0(q.x, q.y, q.s * 1.6, q.s, ctx.fillStyle);
      } else {
        R0(q.x, q.y, q.s, q.s * 0.8, ctx.fillStyle);
        R0(q.x + q.s, q.y + q.s * 0.5, q.s, q.s * 0.6, ctx.fillStyle);
      }
    }
    var motesA = R[PC.ri].motes;
    for (var m = 0; m < motes.length; m++) {
      var mm = motes[m];
      var fl = reduce ? 0.4 : 0.35 + Math.sin(t * 2 + mm.ph) * 0.35;
      ctx.fillStyle = "rgba(" + motesA.col + "," + (motesA.a * fl).toFixed(3) + ")";
      ctx.fillRect(mm.x, mm.y, 2, 2);
    }
    ctx.globalAlpha = 1;

    /* 光柱 / 雾气 / 暗角 */
    if (PC.lightShaft > 0.05) {
      ctx.globalAlpha = PC.lightShaft * 0.16;
      ctx.fillStyle = "rgb(" + PC.glow + ")";
      for (var k = 0; k < 5; k++) {
        var lx = ((k * 420 - cam.x * 0.5) % (vw + 500)) - 200;
        ctx.beginPath();
        ctx.moveTo(lx, 0); ctx.lineTo(lx + 90 * u, 0);
        ctx.lineTo(lx + 230 * u, groundY); ctx.lineTo(lx + 40 * u, groundY);
        ctx.closePath(); ctx.fill();
      }
      ctx.globalAlpha = 1;
    }
    ctx.fillStyle = "rgba(" + PC.haze + ",0.1)";
    ctx.fillRect(0, groundY - 70 * u, vw, 74 * u);
    if (PC.dark > 0.02) {
      ctx.fillStyle = "rgba(6,8,20," + (PC.dark * 0.5).toFixed(2) + ")";
      ctx.fillRect(0, 0, vw, vh);
    }
    var vg = ctx.createRadialGradient(vw / 2, vh * 0.5, vh * 0.35, vw / 2, vh * 0.55, vh);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,.42)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, vw, vh);
  }

  function toneOf(ri) {
    var p = R[ri].pal;
    return { deep: p.accent, mid: p.accentText, hi: p.waterHi };
  }
  function sign(sx, b, zo) {
    if (Math.abs(zo.x - player.x) > 620) return;
    var label = zo.label.split(" · ")[0];
    ctx.font = Math.round(12 * u) + "px ui-monospace, monospace";
    ctx.textAlign = "center";
    var w = ctx.measureText(label).width + 16 * u;
    var y = b - 196 * u;
    ctx.fillStyle = "rgba(10,10,14,.72)";
    ctx.fillRect(sx - w / 2, y, w, 20 * u);
    ctx.strokeStyle = R[zo.ri].pal.accent;
    ctx.lineWidth = 1;
    ctx.strokeRect(sx - w / 2 + 0.5, y + 0.5, w - 1, 20 * u - 1);
    ctx.fillStyle = R[zo.ri].pal.accentText;
    ctx.fillText(label, sx, y + 14 * u);
    ctx.textAlign = "left";
  }

  /* ---------------- 主循环 ---------------- */
  var last = 0, running = true;
  function frame(ts) {
    if (!running) return;
    var dt = Math.min(0.05, (ts - last) / 1000 || 0.016);
    last = ts; now = ts / 1000;
    if (!docMode) { step(dt); render(); }
    requestAnimationFrame(frame);
  }

  function step(dt) {
    var dir = 0;
    if (keys.left) dir -= 1;
    if (keys.right) dir += 1;
    if (target !== null) {
      var d = target - player.x;
      if (Math.abs(d) < 8) { target = null; }
      else dir = d > 0 ? 1 : -1;
    }
    if (dir !== 0) {
      player.x = clamp(player.x + dir * player.speed * dt, 60, worldW - 60);
      player.dir = dir;
      player.walk += dt;
      cam.vel = dir * player.speed * dt;
    } else {
      player.walk = 0;
      cam.vel = 0;
    }
    var want = clamp(player.x - vw / 2, 0, Math.max(0, worldW - vw));
    cam.x = reduce ? want : lerp(cam.x, want, 1 - Math.pow(0.0015, dt));
    stepParticles(dt, now);
    updateNear();
  }

  /* ---------------- 交互点 ---------------- */
  var nearZone = null;
  var promptEl = document.getElementById("prompt");
  function updateNear() {
    var best = null, bd = 1e9;
    for (var i = 0; i < laid.length; i++) {
      var d = Math.abs(laid[i].x - player.x);
      if (d < bd) { bd = d; best = laid[i]; }
    }
    var z = bd < 170 ? best : null;
    if (z !== nearZone) {
      nearZone = z;
      if (z && !panelOpen) {
        promptEl.querySelector(".prompt-text").textContent = z.label.split(" · ")[0];
        promptEl.classList.remove("hidden");
      } else if (!z) promptEl.classList.add("hidden");
    }
    if (z) {
      promptEl.style.left = (z.x - cam.x) + "px";
      promptEl.style.top = (groundY - 210 * u) + "px";
    }
    var badge = document.getElementById("realmBadge");
    var ri = realmAt(player.x);
    if (badge && badge.dataset.ri !== String(ri)) {
      badge.dataset.ri = String(ri);
      badge.textContent = R[ri].name;
      badge.style.borderColor = R[ri].pal.accent;
      badge.style.color = R[ri].pal.accentText;
    }
  }

  /* ---------------- 面板 ---------------- */
  var overlay = document.getElementById("overlay");
  var panelBody = document.getElementById("panelBody");
  var panelTitle = document.getElementById("panelTitle");
  var panelSub = document.getElementById("panelSub");
  var panelIcon = document.getElementById("panelIcon");
  var panelMeta = document.getElementById("panelMeta");
  var panelCta = document.getElementById("panelCta");
  var panelOpen = false, lastFocus = null;

  function zoneById(id) {
    for (var i = 0; i < laid.length; i++) if (laid[i].id === id) return laid[i];
    return null;
  }

  function open(id) {
    var z = zoneById(id);
    if (!z) return;
    lastFocus = document.activeElement;
    var realm = R[z.ri];
    panelTitle.textContent = z.label;
    panelSub.textContent = z.sub;
    panelIcon.setAttribute("href", "#i-" + (z.icon || "gate"));
    overlay.querySelector(".panel").dataset.realm = realm.id;
    panelMeta.innerHTML = (z.meta || (z.kind === "ruler" ? [realm.motto] : [])).map(function (m) {
      return '<span class="chip">' + m + "</span>";
    }).join("");
    var body = z.body || "";
    if (body.charAt(0) === "{") body = realm.ruler.greet;
    panelBody.innerHTML = body;
    panelCta.innerHTML = (z.cta || []).map(function (c) {
      return '<a class="pixel-btn ' + (c.tone || "") + '" href="' + c.href +
             '"><span>' + c.label + "</span></a>";
    }).join("");
    overlay.classList.remove("hidden");
    overlay.setAttribute("aria-hidden", "false");
    panelOpen = true;
    promptEl.classList.add("hidden");
    document.getElementById("panelClose").focus();
    setHash("#" + z.id);
  }

  /* file:// 下 replaceState 会抛 SecurityError，退化到直接写 hash。
     写入期间置 hashSilent，避免自己的写入触发 hashchange 把玩家再弹一次。 */
  var hashSilent = false;
  function setHash(h) {
    if (location.hash === h) return;
    hashSilent = true;
    try {
      try { history.replaceState(null, "", h || location.pathname); }
      catch (e) { location.hash = h || ""; }
    } finally {
      setTimeout(function () { hashSilent = false; }, 0);
    }
  }

  addEventListener("hashchange", function () {
    if (hashSilent) return;
    var id = location.hash.slice(1);
    if (!id) { close(); return; }
    if (zoneById(id)) go(id); else setHash("");
  });

  function close() {
    if (!panelOpen) return;
    overlay.classList.add("hidden");
    overlay.setAttribute("aria-hidden", "true");
    panelOpen = false;
    setHash("");
    if (lastFocus && lastFocus.focus) lastFocus.focus();
    nearZone = null;
    updateNear();
  }

  function interact() {
    if (panelOpen) return close();
    if (nearZone) return open(nearZone.id);
  }

  /* 界碑说明（不在 ZONES 中，由引擎按分界生成） */
  BND.forEach(function (bnd, i) {
    var w = R[i], e = R[i + 1];
    laid.push({
      id: "border-" + i, ri: i, x: bnd.x, kind: "info", icon: "gate",
      label: "界碑 · " + w.name + " ↔ " + e.name,
      sub: w.name + " 与 " + e.name + " 的过渡带",
      meta: ["过渡带", w.Latin + " → " + e.Latin],
      body: '<p class="pb-p">这块碑把 ' + w.name + ' 的 ' + w.motto + '，' +
            '和 ' + e.name + ' 的 ' + e.motto + ' 缝在同一条路上。' +
            '碑西是' + w.land + '，碑东是' + e.land + '。</p>' +
            '<div class="pb-note">再走二十步，脚下的草色与头顶的光就会换完。' +
            '同一位作者走过来的路，本来就不止一种颜色。</div>',
      cta: [
        { href: w.home, label: "回" + w.name, tone: w.id },
        { href: e.home, label: "去" + e.name, tone: e.id },
      ],
    });
  });
  /* 界碑由引擎追加，补回 x 升序，避免依赖顺序的逻辑出错 */
  laid.sort(function (a, b) { return a.x - b.x; });

  /* ---------------- 目录 ---------------- */
  var menu = document.getElementById("menuOverlay");
  function buildMenu() {
    var el = document.getElementById("menuList");
    el.innerHTML = R.map(function (realm, ri) {
      var list = laid.filter(function (z) { return z.ri === ri && z.kind !== "info"; });
      return '<div class="menu-group" style="--ma:' + realm.pal.accent + '">' +
        '<h3>' + realm.name + '<small>' + realm.Latin + " · " + realm.motto + (realm.cat ? " · " + realm.cat : "") + "</small></h3>" +
        list.map(function (z) {
          return '<button data-id="' + z.id + '"><span class="mi-ico">◆</span>' +
                 "<span>" + z.label + "</span><small>" + (z.sub || "") + "</small></button>";
        }).join("") + "</div>";
    }).join("");
    el.querySelectorAll("button").forEach(function (btn) {
      btn.addEventListener("click", function () {
        go(btn.dataset.id);
        toggleMenu(false);
      });
    });
    var foot = document.getElementById("menuBorders");
    if (foot) {
      foot.innerHTML = BND.map(function (bnd, i) {
        var short = function (nm) { return nm.replace("之境", ""); };
        return '<button class="border-btn" data-id="border-' + i + '">' +
               '<span class="mi-ico">◆</span><span>' + short(R[i].name) + " ↔ " + short(R[i + 1].name) +
               "</span></button>";
      }).join("");
      foot.querySelectorAll("button").forEach(function (btn) {
        btn.addEventListener("click", function () {
          go(btn.dataset.id);
          toggleMenu(false);
        });
      });
    }
  }
  function camClamp(v) { return clamp(v, 0, Math.max(0, worldW - vw)); }
  function go(id) {
    var z = zoneById(id);
    if (!z) return;
    player.x = clamp(z.x - 70, 60, worldW - 60);
    player.dir = 1;
    cam.x = camClamp(player.x - vw / 2);
    updateNear();
    open(z.id);
  }
  function toggleMenu(force) {
    var show = force === undefined ? menu.classList.contains("hidden") : force;
    menu.classList.toggle("hidden", !show);
    menu.setAttribute("aria-hidden", String(!show));
    if (show) document.getElementById("menuClose").focus();
  }

  /* ---------------- 文档模式 ---------------- */
  var docMode = false;
  function enableDoc() { setDoc(true); }
  function setDoc(on) {
    docMode = on;
    document.body.classList.toggle("doc-mode", on);
    document.getElementById("modeLabel").textContent = on ? "漫游模式" : "文档模式";
    document.getElementById("modeIcon").setAttribute("href", on ? "#i-play" : "#i-doc");
    if (on) buildDoc();
  }
  function buildDoc() {
    var el = document.getElementById("docList");
    el.innerHTML = R.map(function (realm, ri) {
      var list = laid.filter(function (z) { return z.ri === ri; });
      return '<section class="doc-realm" style="--ma:' + realm.pal.accent + '">' +
        '<h2>' + realm.name + '<small>' + realm.motto + (realm.cat ? " · " + realm.cat : "") + "</small></h2>" +
        list.map(function (z) {
          return '<article class="doc-item"><h3>' + z.label + "</h3>" +
            '<p class="d-sub">' + (z.sub || "") + "</p>" +
            '<p class="d-meta">' + ((z.meta || [realm.motto]).join(" · ")) + "</p>" +
            '<div class="d-body">' + (z.body.charAt(0) === "{" ? realm.ruler.greet : z.body) + "</div>" +
            '<p class="d-cta">' + (z.cta || []).map(function (c) {
              return '<a href="' + c.href + '">' + c.label + " →</a>";
            }).join(" ") + "</p></article>";
        }).join("") + "</section>";
    }).join("");
  }

  /* ---------------- 键盘 / 指针 ---------------- */
  var keys = { left: false, right: false };
  addEventListener("keydown", function (e) {
    var k = e.key.toLowerCase();
    if (k === "arrowleft" || k === "a") { keys.left = true; target = null; }
    if (k === "arrowright" || k === "d") { keys.right = true; target = null; }
    if (k === "e" || k === "enter" || k === " ") { if (!panelOpen) { e.preventDefault(); interact(); } }
    if (k === "escape") { if (panelOpen) close(); if (!menu.classList.contains("hidden")) toggleMenu(false); }
    if (k === "m") toggleMenu();
  });
  addEventListener("keyup", function (e) {
    var k = e.key.toLowerCase();
    if (k === "arrowleft" || k === "a") keys.left = false;
    if (k === "arrowright" || k === "d") keys.right = false;
  });
  addEventListener("blur", function () { keys.left = keys.right = false; });

  cv.addEventListener("pointerdown", function (e) {
    if (panelOpen || docMode) return;
    var wx = e.clientX + cam.x;
    if (nearZone && Math.abs(nearZone.x - wx) < 130) { open(nearZone.id); return; }
    target = clamp(wx, 60, worldW - 60);
  });
  promptEl.addEventListener("click", interact);
  document.getElementById("overlay").addEventListener("pointerdown", function (e) {
    if (e.target.classList.contains("overlay")) close();
  });
  document.getElementById("panelClose").addEventListener("click", close);
  document.getElementById("menuBtn").addEventListener("click", function () { toggleMenu(); });
  document.getElementById("menuClose").addEventListener("click", function () { toggleMenu(false); });
  document.getElementById("modeBtn").addEventListener("click", function () { setDoc(!docMode); });
  document.getElementById("resetBtn").addEventListener("click", function () {
    close(); toggleMenu(false);
    player.x = laid[0].x + 40; player.dir = 1;
    cam.x = clamp(player.x - vw / 2, 0, Math.max(0, worldW - vw));
    history.replaceState(null, "", location.pathname + location.search);
  });
  [["walkBtnL", "left"], ["walkBtnR", "right"]].forEach(function (pair) {
    var el = document.getElementById(pair[0]);
    if (!el) return;
    var set = function (v) { return function (e) { e.preventDefault(); keys[pair[1]] = v; target = null; }; };
    el.addEventListener("pointerdown", set(true));
    el.addEventListener("pointerup", set(false));
    el.addEventListener("pointerleave", set(false));
    el.addEventListener("pointercancel", set(false));
  });
  document.getElementById("interactBtn").addEventListener("click", interact);

  addEventListener("resize", function () {
    resize();
    cam.x = clamp(player.x - vw / 2, 0, Math.max(0, worldW - vw));
  });

  /* ---------------- 启动 ---------------- */
  resize();
  seedParticles();
  buildMenu();
  cam.x = clamp(player.x - vw / 2, 0, Math.max(0, worldW - vw));
  updatePal(player.x);
  updateNear();
  if (location.hash) {
    var z0 = zoneById(location.hash.slice(1));
    if (z0) { player.x = z0.x - 70; cam.x = camClamp(player.x - vw / 2); open(z0.id); }
  }
  requestAnimationFrame(frame);

  /* 供 index.html 与调试读取；player 是实时引用，外部可直接定位 */
  window.__WORLD__ = {
    laid: laid, realms: R, worldW: worldW, borders: BND,
    go: go, open: open, close: close, player: player,
  };
})();
