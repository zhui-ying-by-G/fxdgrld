/* ============================================================
   zones.js — 六境领地作品集 · 内容配置
   ------------------------------------------------------------
   这是新增作品时唯一需要改动的文件。world.js / index.html 不用碰。

   六个境（自西向东）：
     0 铜金之境 gold   桌游      → ../games/
     1 青玉之境 jade   小说      → ../novels/
     2 琉璃之境 glass  壁纸      → ../wallpaper/
     3 回声之境 echo   音乐      → ../music/      （奠基）
     4 走马之境 lamp   漫剧      → ../comics/     （奠基）
     5 授业之境 chalk  教育      → ../lessons/    （奠基）

   一条 REALM 除名字外还要填两个字段：
     land : 一句话地貌描述，界碑面板会引用
     home : 该境对应的类目页，界碑面板的按钮会跳过去

   一个作品 = ZONES 里的一条记录：
     realm : 境序号 0–5
     id    : URL 锚点（/portfolio/#novel 可直达），必须唯一、短、用连字符
     kind  : "ruler" 君主（每境恰好一条，排在最西） / "work" 作品建筑
     draw  : 建筑画法，取值见 world.js 的 DRAW：
             throne 王座 / found 奠基石 / hall 议事厅 / library 典章阁
             drill 演武场 / scrollhouse 史阁 / study 书斋 / mailbox 信箱
             gallery 长廊 / lightbox 光盒 / atelier 工棚 / board 分镜墙
             stage 乐台 / lectern 讲台
     icon  : 面板标题图标，取值见 index.html 里的 <symbol id="i-*">
     label : 建筑招牌（面板标题）
     sub   : 一行副标题（提示气泡 + 面板副标题）
     meta  : 状态标签数组，渲染成面板顶部的小徽标
     body  : 面板正文，允许 HTML。"{" 开头会被替换成该境君主的 greet。
             <p class="pb-p"> 正文段落
             <div class="pb-note"> 引述 / 旁注
             <div class="pb-row"> 一行标签
     cta   : 按钮数组 [{ href, label, tone }]，tone 取境 id 或 ""
   位置无需填写：引擎按境内出现顺序自动排布，并保证 ≥minClear 间距。

   诚实约定：没有成品的类目一律用 draw:"found"（未合拢的脚手架）+
   meta 写明「筹备中」，正文只列已有素材与缺口，不写成已完成。
   ============================================================ */

(function (global) {
  "use strict";

  /* ---------------- 两位君主与两套地貌 ---------------- */
  var REALMS = [
    {
      id: "gold",
      name: "铜金之境",
      Latin: "Kupfergold",
      motto: "掌规则、图纸与棋盘",
      cat: "桌游",
      land: "黄昏、干叶与铜色",
      home: "../games/",
      ruler: {
        name: "典制",
        title: "铜金之王",
        // 君主王座面板正文
        greet:
          '<p class="pb-p">这边的疆域归我管。凡是<b>先立规则、再谈好看</b>的东西都放在这里：' +
          '桌游的机制与平衡表、架空世界的设定与年表、以及为它们服务的代码与排版。</p>' +
          '<div class="pb-note">「我这一系的档案有个共同点：可以交给别人执行。' +
          '规则写清了，换了主持人也照样能开局。」</div>' +
          '<p class="pb-p">往东还有五个境。它们共用这一条路——' +
          '同一个人手下的六种笔性，本该走在一片地上。</p>',
      },
      /* 地貌色：黄昏 / 干秋 —— 暖、亮、尘感 */
      pal: {
        skyTop: "#2c2a46", skyMid: "#7c5a55", skyLow: "#e9b86b",
        ridgeFar: "#6a5f7c", ridgeMid: "#7d6350", ridgeNear: "#8a6b46",
        hillFar: "#9a7c40", hillNear: "#7c6232",
        treeFar: "#b47327", treeMid: "#9a5a22", treeNear: "#6f4320", trunk: "#4a3120",
        grassTop: "#c19a4a", grass: "#9c7a38", grassDeep: "#6a5126",
        dirt: "#7a5a38", dirtLine: "#5c4227", path: "#c0a071", pathEdge: "#8b6f47",
        stone: "#9c8a6a", stoneDeep: "#5f5140",
        water: "#c9a24f", waterHi: "#ffe6ab",
        glow: "255, 206, 120", haze: "232, 198, 150", tint: "255, 214, 150",
        accent: "#c8a84e", accentText: "#e6c877",
        starA: 0.25, sunA: 1, sunY: 0.3, moonA: 0.15, lightShaft: 0.75, dark: 0.05,
      },
      weather: { type: "leaf", rate: 14, cols: ["#e8b96a", "#c19a4a", "#a86e2c", "#ffe0a3"], size: 3, fall: 22, drift: 30 },
      motes: { rate: 10, col: "255, 226, 168", a: 0.5 },
    },
    {
      id: "jade",
      name: "青玉之境",
      Latin: "Celadon",
      motto: "掌文字、年月与故事",
      cat: "小说",
      land: "初夜、飞萤与青玉",
      home: "../novels/",
      ruler: {
        name: "编年",
        title: "青玉之王",
        greet:
          '<p class="pb-p">铜金那边管“怎么算”，我这边只管“发生了什么”。' +
          '小说、编年、日记、随手画的东西——凡是<b>带日期的</b>，都归我。</p>' +
          '<div class="pb-note">「我从不校对他的表格，他也不会替我删一段闲话。' +
          '共用一张地图，是为了让来看的人不必在几个网站之间来回跳。」</div>' +
          '<p class="pb-p">再往东是琉璃地界。他把我的形容词画成了画面——' +
          '我不介意，反正素材都是我给的。</p>',
      },
      /* 地貌色：初夜 / 春水 —— 冷、暗、星感 */
      pal: {
        skyTop: "#0c1128", skyMid: "#1b2c50", skyLow: "#3c5f74",
        ridgeFar: "#33456b", ridgeMid: "#2a3c5c", ridgeNear: "#26485e",
        hillFar: "#2f6a5e", hillNear: "#255049",
        treeFar: "#3d8a78", treeMid: "#2f6f63", treeNear: "#1f4e49", trunk: "#2a3f3a",
        grassTop: "#4e9c7a", grass: "#3a7d64", grassDeep: "#255245",
        dirt: "#3a5a52", dirtLine: "#26413b", path: "#79a99a", pathEdge: "#4c7568",
        stone: "#6d8a92", stoneDeep: "#3a5259",
        water: "#5fd0b4", waterHi: "#b6f2e2",
        glow: "156, 234, 219", haze: "130, 190, 200", tint: "150, 230, 220",
        accent: "#5fd0b4", accentText: "#9ceadb",
        starA: 1, sunA: 0.08, sunY: 0.9, moonA: 1, lightShaft: 0.15, dark: 0.35,
      },
      weather: { type: "petal", rate: 11, cols: ["#9ceadb", "#7fd8c4", "#dff6ee", "#b6f2e2"], size: 3, fall: 18, drift: 24 },
      motes: { rate: 14, col: "182, 242, 226", a: 0.65 },
    },
    {
      id: "glass",
      name: "琉璃之境",
      Latin: "Vitrea",
      motto: "掌光影、画面与像素",
      cat: "壁纸",
      land: "破晓、薄雾与蓝玻璃",
      home: "../wallpaper/",
      ruler: {
        name: "琢光",
        title: "琉璃之王",
        greet:
          '<p class="pb-p">我这一境不放长文，只放<b>能挂在屏幕上</b>的东西。' +
          '两组系列、两套会动的壁纸工程，加上一条我自己搭的出图流水线。</p>' +
          '<div class="pb-row"><b>已有</b><span>《暮秋物语》 · 《巨映山河》 · Lively 动态壁纸 ×2 · 提示词套件</span></div>' +
          '<div class="pb-note">「画图最怕的不是画得慢，是每一张都得重来一遍。' +
          '所以我把风格、角色、镜头拆成锁死的提示词块——' +
          '换人跑也是同一个画面，这才叫系列。」</div>',
      },
      /* 地貌色：破晓 —— 冷亮、薄雾、蓝玻璃 */
      pal: {
        skyTop: "#141d33", skyMid: "#3d5a80", skyLow: "#9dc2d8",
        ridgeFar: "#4a6488", ridgeMid: "#3f587a", ridgeNear: "#35506e",
        hillFar: "#3e6a80", hillNear: "#33566b",
        treeFar: "#5b8fae", treeMid: "#476f8f", treeNear: "#345468", trunk: "#2a3646",
        grassTop: "#5f8fa6", grass: "#4a7188", grassDeep: "#2f4a5a",
        dirt: "#3d5468", dirtLine: "#2b3d4c", path: "#8fb4c8", pathEdge: "#5c7f94",
        stone: "#7d97a8", stoneDeep: "#43596a",
        water: "#79c6e8", waterHi: "#d6f1ff",
        glow: "184, 220, 245", haze: "160, 200, 225", tint: "190, 230, 255",
        accent: "#7fb2e0", accentText: "#b8dcf5",
        starA: 0.35, sunA: 0.9, sunY: 0.42, moonA: 0.4, lightShaft: 0.6, dark: 0.08,
      },
      weather: { type: "shard", rate: 12, cols: ["#d6f1ff", "#9fd0ee", "#7fb2e0", "#ffffff"], size: 3, fall: 16, drift: 22 },
      motes: { rate: 16, col: "200, 235, 255", a: 0.6 },
    },
    {
      id: "echo",
      name: "回声之境",
      Latin: "Resona",
      motto: "掌节拍、噪声与残响",
      cat: "音乐",
      land: "深夜、紫月与余响",
      home: "../music/",
      ruler: {
        name: "拾响",
        title: "回声之主 · 奠基中",
        greet:
          '<p class="pb-p">这一境<b>还没有王座</b>。你看到的是脚手架：地基放好了，' +
          '墙上目前只挂得住一样东西。</p>' +
          '<div class="pb-row"><b>已有</b><span>一首成品器乐习作，2 分 22 秒，站内可试听</span></div>' +
          '<div class="pb-row"><b>缺口</b><span>混音链路未定 · 没有第二首 · 没有封面与曲目说明</span></div>' +
          '<div class="pb-note">「我没有拿得出手的第二首，所以这里不写“代表作”。' +
          '等地基上真的盖起东西，这块奠石会换成王座。」</div>',
      },
      /* 地貌色：深夜 —— 靛紫、低照度、以月为主光 */
      pal: {
        skyTop: "#0b0a1c", skyMid: "#241a3c", skyLow: "#4a3260",
        ridgeFar: "#3a2c56", ridgeMid: "#31264a", ridgeNear: "#282040",
        hillFar: "#2e2448", hillNear: "#241c3a",
        treeFar: "#4a3a6a", treeMid: "#3a2d55", treeNear: "#2a2140", trunk: "#1f1a2e",
        grassTop: "#4a3d68", grass: "#3a2f52", grassDeep: "#271f38",
        dirt: "#332848", dirtLine: "#241c34", path: "#6a5a86", pathEdge: "#443858",
        stone: "#6a5f80", stoneDeep: "#3a3350",
        water: "#9a6fc4", waterHi: "#d8b8f0",
        glow: "190, 150, 230", haze: "150, 120, 190", tint: "200, 160, 240",
        accent: "#9a6fc4", accentText: "#c9a6e8",
        starA: 1, sunA: 0.02, sunY: 1.1, moonA: 0.9, lightShaft: 0.1, dark: 0.42,
      },
      weather: { type: "note", rate: 9, cols: ["#c9a6e8", "#9a6fc4", "#e8d6f8", "#ffffff"], size: 2, fall: 10, drift: 20 },
      motes: { rate: 18, col: "216, 184, 240", a: 0.7 },
    },
    {
      id: "lamp",
      name: "走马之境",
      Latin: "Cursus",
      motto: "掌分镜、镜头与节奏",
      cat: "漫剧",
      land: "夜灯、炭火与走马影",
      home: "../comics/",
      ruler: {
        name: "分光",
        title: "走马之主 · 奠基中",
        greet:
          '<p class="pb-p">走马灯的原理是：画不动，<b>影动</b>。' +
          '我这一境停在“画”这一层——四部作品有分镜，一部都还没有成片。</p>' +
          '<div class="pb-row"><b>已有</b><span>《神机蛊境》EP01《照夜》分镜指导 · 《巨映山河》分镜板与《极境篇》指导 · 《暮秋物语》第二、三辑分镜方案</span></div>' +
          '<div class="pb-row"><b>缺口</b><span>无样片 · 无配音与音效 · 无成片时长</span></div>' +
          '<div class="pb-note">「分镜指导是写给未来那个开工的人看的：' +
          '每一格给多长、镜头怎么动、声音在哪一拍进。' +
          '先把它写死，将来才有得可拍。」</div>',
      },
      /* 地貌色：夜 —— 走马灯的红橙，炭与纸影 */
      pal: {
        skyTop: "#1a0f14", skyMid: "#3f1e22", skyLow: "#8a4230",
        ridgeFar: "#4a2830", ridgeMid: "#3e2228", ridgeNear: "#331c22",
        hillFar: "#5a2e2a", hillNear: "#442322",
        treeFar: "#7a3a30", treeMid: "#5e2c26", treeNear: "#42201c", trunk: "#2c1714",
        grassTop: "#8a4a38", grass: "#6b382a", grassDeep: "#48251c",
        dirt: "#5c3226", dirtLine: "#3f2118", path: "#b0755a", pathEdge: "#7a4c38",
        stone: "#8a6a5c", stoneDeep: "#4e382e",
        water: "#e07a4e", waterHi: "#ffc79a",
        glow: "255, 178, 128", haze: "220, 150, 120", tint: "255, 190, 150",
        accent: "#d4654f", accentText: "#f0937c",
        starA: 0.5, sunA: 0.05, sunY: 1.0, moonA: 0.6, lightShaft: 0.35, dark: 0.28,
      },
      weather: { type: "ember", rate: 13, cols: ["#ffc79a", "#f0937c", "#d4654f", "#ffe6cf"], size: 2, fall: 8, drift: 26 },
      motes: { rate: 15, col: "255, 190, 140", a: 0.62 },
    },
    {
      id: "chalk",
      name: "授业之境",
      Latin: "Doctrina",
      motto: "掌讲义、排版与批改",
      cat: "教育",
      land: "清早、粉笔灰与素白",
      home: "../lessons/",
      ruler: {
        name: "执灯",
        title: "授业之主 · 奠基中",
        greet:
          '<p class="pb-p">这一境放的是<b>能被别人拿去用的东西</b>：' +
          '印刷级试卷排版、组卷流水线、讲义模板。它们都在跑，但都还不是课程。</p>' +
          '<div class="pb-row"><b>已有</b><span>LaTeX 试卷模板（密封线 / 装订线 / 评分栏） · 拍题→识别→组卷→成卷的自动化原型 · 在校研究项目的推导笔记</span></div>' +
          '<div class="pb-row"><b>缺口</b><span>没有系统讲义 · 没有授课记录 · 样例题库仍未公开</span></div>' +
          '<div class="pb-note">「我把这一境标成奠基，是因为“会排版”不等于“会教”。' +
          '前者已经能交给别人用，后者我还在学习。」</div>',
      },
      /* 地貌色：清早 —— 素白冷灰，灯下课桌 */
      pal: {
        skyTop: "#2a3540", skyMid: "#61757f", skyLow: "#d3dcd8",
        ridgeFar: "#7e8f96", ridgeMid: "#6b7c84", ridgeNear: "#5c6d75",
        hillFar: "#6e8288", hillNear: "#5b6e74",
        treeFar: "#8fa3a0", treeMid: "#748a88", treeNear: "#596d6c", trunk: "#3e4244",
        grassTop: "#a8b6ac", grass: "#8a9a92", grassDeep: "#63736d",
        dirt: "#7e8884", dirtLine: "#5e6764", path: "#d6ddd6", pathEdge: "#9aa6a0",
        stone: "#b0bab8", stoneDeep: "#6c7674",
        water: "#bcd0d4", waterHi: "#f2f8fa",
        glow: "235, 242, 245", haze: "210, 220, 222", tint: "240, 248, 250",
        accent: "#b9c6d6", accentText: "#eaf1f8",
        starA: 0.05, sunA: 0.85, sunY: 0.34, moonA: 0.05, lightShaft: 0.8, dark: 0.0,
      },
      weather: { type: "chalk", rate: 9, cols: ["#f2f8fa", "#dfe7ea", "#c3d0d6", "#ffffff"], size: 2, fall: 10, drift: 14 },
      motes: { rate: 12, col: "240, 248, 250", a: 0.5 },
    },
  ];

  /* ---------------- 作品分区（自西向东） ---------------- */
  var ZONES = [
    /* ======== 铜金之境 ======== */
    {
      realm: 0, kind: "ruler", id: "throne-gold", draw: "throne", icon: "crown",
      label: "典制王座", sub: "铜金之王 · 掌规则与图纸",
      body: "{ruler.greet}",
      cta: [
        { href: "../games/", label: "桌游类目", tone: "gold" },
        { href: "../kingdom/", label: "进入王权党争", tone: "gold" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 0, kind: "work", id: "board", draw: "hall", icon: "dice",
      label: "议事厅 · 《王权党争》", sub: "原创策略桌游 · 规则 v1.4",
      meta: ["桌游设计", "推荐 6 – 8 人 · 约 2 小时", "已上线"],
      body:
        '<p class="pb-p">1918 年魏玛共和国。玩家扮演国会中民主、共和两党的议员，' +
        '每人另持一张<b>背面朝上、任何人不得展示</b>的理想身份牌。' +
        '谈判、结盟、背叛、立法，直到共和国要么活下来、要么在街头被推翻。</p>' +
        '<div class="pb-row"><b>设计核心</b><span>谈判的收益必须大于独走。</span></div>' +
        '<p class="pb-p">四个版本、两轮内测，把六党胜率差距从 40% 收敛到 10% 以内；' +
        'v1.2 起极右与极左路线形成真正的第三种赢法。</p>',
      cta: [
        { href: "../games/", label: "桌游类目", tone: "gold" },
        { href: "../kingdom/", label: "专区首页", tone: "gold" },
        { href: "../kingdom/manual.html", label: "完整说明书", tone: "" },
      ],
    },
    {
      realm: 0, kind: "work", id: "manual", draw: "library", icon: "book",
      label: "典章阁 · 完整说明书", sub: "十章全文 · 可打印",
      meta: ["规则文档", "150 张卡牌 · 20 名议员 · 8 种结局", "含蚀刻插画"],
      body:
        '<p class="pb-p">从明暗双身份到结算流程的全部技术文档。' +
        '写它的原因是：内测时每次争议都要我口头裁定，' +
        '而口头裁定不可复现——所以每一条都落到纸上，配插图与例外条款。</p>' +
        '<div class="pb-note">这一页最初把 9 张插画内嵌成了 Base64，整页 2.9 MB，' +
        '移动端首屏要等十几秒。抽出图片后降到 84 KB。</div>',
      cta: [{ href: "../kingdom/manual.html", label: "翻开说明书", tone: "gold" }],
    },
    {
      realm: 0, kind: "work", id: "drill", draw: "drill", icon: "flag",
      label: "演武场 · 新手教程", sub: "按回合顺序走一遍首局",
      meta: ["入门", "约 15 分钟读完"],
      body:
        '<p class="pb-p">说明书回答“这条规则怎么算”，教程只回答“第一局该怎么打”。' +
        '按回合顺序走一遍，标出最容易误读的三处条款，并给一版推荐开局。</p>' +
        '<p class="pb-p">给设计师的旁注：所有规则书都该配一份这样的东西——' +
        '读者不会因为规则完整就敢开局。</p>',
      cta: [{ href: "../kingdom/tutorial.html", label: "开始演练", tone: "gold" }],
    },

    /* ======== 青玉之境 ======== */
    {
      realm: 1, kind: "ruler", id: "throne-jade", draw: "throne", icon: "crown",
      label: "编年王座", sub: "青玉之王 · 掌文字与年月",
      body: "{ruler.greet}",
      cta: [
        { href: "../novels/", label: "小说类目", tone: "jade" },
        { href: "../qiufengdu/", label: "《秋风渡》", tone: "jade" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 1, kind: "work", id: "atlas", draw: "scrollhouse", icon: "scroll",
      label: "史阁 · 《川帝国编年卷轴》", sub: "架空世界设定 · 六卷",
      meta: ["世界观", "编年体 · 史家手记", "景和七年"],
      body:
        '<p class="pb-p">新川大陆：六大文明、八个族源、三场决定国运的大战，' +
        '以及一份两千年大事年表。体例仿史家手记——由一位“走南闯北的旅行者”' +
        '从灰烬里捡回竹简，把它们整理成卷。</p>' +
        '<div class="pb-row"><b>六卷</b><span>卷首 · 编年 · 列国 · 诸族 · 兵燹 · 人物</span></div>' +
        '<p class="pb-p">它先是小说的地基，后来自己成了作品：' +
        '设定集的可读性来自“有人在做整理”这个动作，而不来自条目数量。</p>',
      cta: [{ href: "../chuan/", label: "展开卷轴", tone: "jade" }],
    },
    {
      realm: 1, kind: "work", id: "novel", draw: "study", icon: "quill",
      label: "书斋 · 《秋风渡》", sub: "长篇小说 · 卷一《灰烬之城》已完结",
      meta: ["长篇", "约 3.7 万字", "单元剧结构"],
      body:
        '<p class="pb-p">海运初开，旧账未清。看船的先生、藏名的商女、算账的长子、押镖的女会长——' +
        '四个人从一张半契开始，替一座断粮的城对账。</p>' +
        '<div class="pb-note">对账是我写作里反复出现的动作：' +
        '把一个说不清的局，逐项摊开到所有人都无法再装糊涂。</div>' +
        '<p class="pb-p">第一卷已完结，第二卷在写。' +
        '卷内按单元推进，每卷末尾留一条跨卷的暗线。</p>',
      cta: [
        { href: "../qiufengdu/", label: "作品页", tone: "jade" },
        { href: "../qiufengdu/vol1.html", label: "卷一正文", tone: "" },
      ],
    },
    {
      realm: 1, kind: "work", id: "mailbox", draw: "mailbox", icon: "mail",
      label: "树洞信箱 · 日记", sub: "零散记录 · 按日期倒序",
      meta: ["进行中"],
      body:
        '<p class="pb-p">这里放不成形的东西：读到的、想到的、某天的天气与当天做的事。' +
        '条目用 Markdown 撰写，一条一文件，由构建脚本生成索引页与正文页。</p>' +
        '<div class="pb-note">尚未开放。现在能看的全部登记在王国档案馆——' +
        '包括那些只完成了一半的设计。</div>',
      cta: [{ href: "../archives/", label: "先去档案馆", tone: "" }],
    },

    /* ======== 2 琉璃之境 · 壁纸 ======== */
    {
      realm: 2, kind: "ruler", id: "throne-glass", draw: "throne", icon: "crown",
      label: "琢光王座", sub: "琉璃之王 · 掌光影与画面",
      body: "{ruler.greet}",
      cta: [
        { href: "../wallpaper/", label: "壁纸类目", tone: "glass" },
        { href: "../wallpaper/dynamic.html", label: "动态壁纸", tone: "glass" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 2, kind: "work", id: "gallery", draw: "gallery", icon: "frame",
      label: "长廊 · 静态图集", sub: "《暮秋物语》《巨映山河》两组系列",
      meta: ["壁纸", "2016 × 1152 交付", "持续更新"],
      body:
        '<p class="pb-p">两组方向不同的系列。<b>《暮秋物语》</b>是动漫插画：' +
        '一个女孩与一个男孩在秋天各自的路上，各带一只只有他们看得见的伴生灵，' +
        '细线稿加水彩洗染，留足负空间，给桌面图标和文字让位。</p>' +
        '<p class="pb-p"><b>《巨映山河》</b>是巨物风景：' +
        '把人与建筑的比例拉到失真——巨门、石阶、沉像、环城、神树——' +
        '再用倒影与水面把它们接回可看的尺度。</p>' +
        '<div class="pb-row"><b>第一批</b><span>《巨映山河》已出 12 张，含 3 张细节图</span></div>',
      cta: [
        { href: "../wallpaper/", label: "进长廊", tone: "glass" },
        { href: "../wallpaper/muqiu.html", label: "《暮秋物语》", tone: "" },
      ],
    },
    {
      realm: 2, kind: "work", id: "dynamic", draw: "lightbox", icon: "play",
      label: "光盒 · 动态壁纸", sub: "两套 Lively 工程 · 会动的那种",
      meta: ["动态壁纸", "Lively Wallpaper", "可下载"],
      body:
        '<p class="pb-p">网页写的循环动画，交给 Lively 当桌面。' +
        '两套工程都在本机跑通过，打包成 zip，拖进 Lively 就能用。</p>' +
        '<div class="pb-row"><b>《方尖碑》</b><span>struct-01-obelisk v2 · 单体建筑 + 光尘循环</span></div>' +
        '<div class="pb-row"><b>《巨映山河》</b><span>分镜板合成动态版 · 图层视差 + 水面反光</span></div>' +
        '<div class="pb-note">动态壁纸真正的成本不在动，在<b>不能打扰</b>：' +
        '图标压上去还认得出、循环点要藏得住、CPU 得压在个位数。' +
        '这三条我写进了工程说明。</div>',
      cta: [{ href: "../wallpaper/dynamic.html", label: "下载与用法", tone: "glass" }],
    },
    {
      realm: 2, kind: "work", id: "pipeline", draw: "atelier", icon: "gear",
      label: "工棚 · 出图流水线", sub: "提示词套件 + 放大脚本",
      meta: ["工作流", "ComfyUI", "可复用"],
      body:
        '<p class="pb-p">一个系列要成立，靠的不是运气好出的那一张，是<b>下一张还得像同一系列</b>。' +
        '所以我把提示词拆成锁死的几块：女角 / 男角 / 伴生灵 / 生灵 / 画风，' +
        '只换镜头与时段，其余一字不改。</p>' +
        '<div class="pb-row"><b>交付规格</b><span>先 1792 × 1024 出四张挑一张，再放大到 2560 × 1440</span></div>' +
        '<p class="pb-p">附带一份挑图清单和一段本地放大脚本。' +
        '清单上写的是“这张为什么被淘汰”，比“这张为什么留下”更有用。</p>',
      cta: [{ href: "../wallpaper/workflow.html", label: "看这套流程", tone: "glass" }],
    },

    /* ======== 3 回声之境 · 音乐（奠基） ======== */
    {
      realm: 3, kind: "ruler", id: "stone-echo", draw: "found", icon: "note",
      label: "拾响 · 奠基石", sub: "回声之主 · 领地未成",
      meta: ["筹备中", "已有素材 1 件", "缺口：混音链路与第二首"],
      body: "{ruler.greet}",
      cta: [
        { href: "../music/", label: "看这块地基", tone: "echo" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 3, kind: "work", id: "listen", draw: "stage", icon: "note",
      label: "试听台 · 目前只有一首", sub: "器乐习作 · 2 分 22 秒",
      meta: ["已有", "站内试听", "暂无标题，暂称《曲目一》"],
      body:
        '<p class="pb-p">一首器乐习作，2 分 22 秒，站内直接播。' +
        '默认不自动播放，也不做音量惊喜。</p>' +
        '<div class="pb-note">它还没有名字，也没有封面。' +
        '我不打算为它编一段作品说明——它现在的诚实身份就是「一首还没做完的曲子」。</div>' +
        '<p class="pb-p">放在这里的原因很简单：这一境要开工，' +
        '总得先有第一件东西挂在墙上，哪怕只是一首习作。</p>',
      cta: [{ href: "../music/", label: "去试听页", tone: "echo" }],
    },
    {
      realm: 3, kind: "work", id: "request", draw: "mailbox", icon: "mail",
      label: "点歌信箱 · 筹备中", sub: "想听什么、正在做什么，先收着",
      meta: ["筹备中"],
      body:
        '<p class="pb-p">这个箱子是<b>空的</b>，先立在这儿。' +
        '我打算用它收两样东西：想翻的曲子，和每次录音踩到的坑。</p>' +
        '<div class="pb-row"><b>开工前要先定</b><span>录音链路 · 混音参照 · 发布节奏</span></div>',
      cta: [{ href: "mailto:2301465049@qq.com", label: "来信", tone: "" }],
    },

    /* ======== 4 走马之境 · 漫剧（奠基） ======== */
    {
      realm: 4, kind: "ruler", id: "stone-lamp", draw: "found", icon: "film",
      label: "分光 · 奠基石", sub: "走马之主 · 有分镜无成片",
      meta: ["筹备中", "已有分镜 4 部", "缺口：样片与配音"],
      body: "{ruler.greet}",
      cta: [
        { href: "../comics/", label: "看这块地基", tone: "lamp" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 4, kind: "work", id: "boards", draw: "board", icon: "film",
      label: "分镜墙 · 四部在案", sub: "每格给多长、镜头怎么动",
      meta: ["分镜阶段", "4 部 · 均为指导文档", "无成片"],
      body:
        '<p class="pb-p">墙上四份东西，都是<b>分镜指导</b>而不是成片：</p>' +
        '<div class="pb-row"><b>《神机蛊境》</b><span>EP01《照夜》· 逐格指导 + 分镜预览图</span></div>' +
        '<div class="pb-row"><b>《巨映山河》</b><span>整片分镜板 + 第二期《极境篇》指导</span></div>' +
        '<div class="pb-row"><b>《暮秋物语》</b><span>第二辑 / 第三辑《一秋》分镜方案</span></div>' +
        '<p class="pb-p">后两组挂在原作壁纸系列下面——同一批画面，' +
        '一种用法是贴在桌面上，另一种用法是按顺序放。</p>' +
        '<div class="pb-note">写分镜指导的收获是：它会当场暴露叙事没想清楚的地方。' +
        '想不出第三格为什么接得住第四格，就说明这一段根本不该存在。</div>',
      cta: [
        { href: "../comics/", label: "读分镜指导", tone: "lamp" },
        { href: "../wallpaper/", label: "回到原画", tone: "glass" },
      ],
    },
    {
      realm: 4, kind: "work", id: "screen", draw: "lightbox", icon: "play",
      label: "放映棚 · 空置", sub: "样片还没有，灯先不点",
      meta: ["筹备中", "缺口：剪辑、配音、音效"],
      body:
        '<p class="pb-p">这一间<b>目前不放任何东西</b>。' +
        '等第一部样片剪出来，这里会先放它，再谈排期与集数。</p>' +
        '<div class="pb-note">我不想用分镜预览图冒充成片。' +
        '静态图再好看，也证明不了节奏是对的。</div>',
      cta: [{ href: "../comics/", label: "类目页说明", tone: "" }],
    },

    /* ======== 5 授业之境 · 教育（奠基） ======== */
    {
      realm: 5, kind: "ruler", id: "stone-chalk", draw: "found", icon: "desk",
      label: "执灯 · 奠基石", sub: "授业之主 · 会排版不等于会教",
      meta: ["筹备中", "已有工具链", "缺口：系统讲义与授课记录"],
      body: "{ruler.greet}",
      cta: [
        { href: "../lessons/", label: "看这块地基", tone: "chalk" },
        { href: "../archives/", label: "王国档案馆", tone: "" },
      ],
    },
    {
      realm: 5, kind: "work", id: "typeset", draw: "lectern", icon: "doc",
      label: "讲台 · 排版与成卷", sub: "LaTeX 试卷模板 + 组卷流水线",
      meta: ["可用", "印刷级", "XeLaTeX"],
      body:
        '<p class="pb-p">一套 XeLaTeX 试卷模板：密封线、装订线、评分栏、题型分节、' +
        '公式与图形混排一次到位，产出直接拿去印刷。</p>' +
        '<div class="pb-row"><b>流水线</b><span>拍题照片 → 版面分析与公式识别 → 按知识点与难度组卷 → 生成 LaTeX → 编译成卷与答题卡</span></div>' +
        '<div class="pb-note">这套东西的起点是很朴素的烦：' +
        '每出一版卷子都要在编辑器里手调两小时边距。' +
        '把它写成模板之后，我改的是内容，不再是排版。</div>' +
        '<p class="pb-p">流水线本身是个人研究项目，样例题库未公开。</p>',
      cta: [{ href: "../lessons/", label: "看模板与样例", tone: "chalk" }],
    },
    {
      realm: 5, kind: "work", id: "handout", draw: "library", icon: "book",
      label: "书架 · 讲义与笔记", sub: "在写的、写了一半的",
      meta: ["筹备中", "含在校研究项目笔记"],
      body:
        '<p class="pb-p">书架上是<b>半成品</b>：一份在校研究项目（多物理场仿真方向）' +
        '的推导与操作笔记，几页写给同学看的入门提纲，以及还没成形的讲义目录。</p>' +
        '<div class="pb-row"><b>为什么先登记</b><span>写不清的地方，就是自己没懂的地方。</span></div>' +
        '<p class="pb-p">等提纲长成能交给别人自学的样子，这一境才配换掉脚手架。</p>',
      cta: [
        { href: "../lessons/", label: "类目页", tone: "chalk" },
        { href: "../archives/", label: "全部档案", tone: "" },
      ],
    },
  ];

  /* ---------------- 世界参数 ---------------- */
  var WORLD = {
    spacing: 1150,     // 同一境内相邻建筑的间距
    realmGap: 1500,    // 两境交界留白（界碑立于中点）
    edgePad: 420,      // 东西两端留白
    minClear: 320,     // 建筑间最小净距，供校验
  };

  global.REALMS = REALMS;
  global.ZONES = ZONES;
  global.WORLD = WORLD;
})(window);
